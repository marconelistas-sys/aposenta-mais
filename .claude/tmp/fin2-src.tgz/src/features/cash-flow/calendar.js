import { renderPaymentList } from './payments.js'
import { state, updateCashFlow } from '../../app/state.js'
import { financialCalendar, validateCommitment, debtSchedule } from '../../domain/financial-calendar.js'
import { currencies } from '../../shared/currencies.js'
import { escapeHtml, privateCurrency } from '../../shared/formatters.js'
import { debtExtraFields, parseDebtExtraPayments, renderDebtDetails } from './debt-details.js'
import { renderAnnualPlanning } from '../plan/annual-planning.js'
import { categoryById } from '../../data/cash-flow-categories.js'
import { expenseCategoryOptions } from '../plan/annual-planning.js'
export const calendarView = { month: new Date().toISOString().slice(0, 7) }
export function saveCommitment(data) {
  const current = state.cashFlow.commitments || []
  const id = data.get('id') || crypto.randomUUID()
  if (data.get('id') && !current.some(item => item.id === id)) throw new Error('Compromisso não encontrado.')
  if (!data.get('id') && current.length >= 50) throw new Error('Limite de 50 compromissos.')
  const item = { id, name: String(data.get('name') || '').trim(), kind: data.get('kind'), amount: Number(data.get('amount')), currency: data.get('currency'), date: data.get('date'), saved: Number(data.get('saved') || 0), installments: Number(data.get('installments')), annualRate: Number(data.get('annualRate')) / 100 }
  if (item.kind === 'debt') { item.amortization = data.get('amortization') || 'price'; item.monthlyFee = Number(data.get('monthlyFee') || 0); item.extraPayments = parseDebtExtraPayments(data.get('extraPayments') || '') }
  const category = categoryById(String(data.get('categoryId') || ''), state.customCategories)
  if (data.get('categoryId') && category?.type !== 'expense') throw new Error('Escolha uma categoria de despesa.')
  if (category) item.categoryId = category.id
  validateCommitment(item)
  updateCashFlow({ commitments: [...current.filter(row => row.id !== id), item] })
}
export function renderCalendar() {
  const { events, undated } = financialCalendar(state.cashFlow, calendarView.month)
  const money = (value, currency) => privateCurrency(value, state.valuesHidden, true, currency)
  const field = (name, label, type, extra = '') => `<label class="form-field"><span>${label}</span><input type="${type}" name="${name}" ${extra} required /></label>`
  return `<section class="page-heading"><div><h1>Calendário, dívidas e metas</h1><p><a href="/contas" data-route>Contas e movimentos</a> · <a href="/consorcios" data-route>Gerenciar consórcios</a> · <a href="/riscos" data-route>Ver impacto patrimonial e riscos</a></p><p>Veja vencimentos e confirme pagamentos já registrados nas contas. O calendário usa a data inicial como vencimento e mostra o valor anual inteiro no mês de pagamento.</p></div><a href="/orcamento" data-route>Voltar ao orçamento</a></section><section class="panel settings-card"><form data-calendar-month><label class="form-field"><span>Mês do calendário</span><input type="month" name="month" value="${calendarView.month}" required /></label><button class="button button--secondary">Consultar mês</button></form>
  ${renderPaymentList(calendarView.month)}
  <p>${undated.length} lançamento(s) sem data de início. <a href="/orcamento" data-route>Defina o vencimento no orçamento</a> para incluí-los no calendário.</p></section>${renderAnnualPlanning('annualGoals')}
  <section class="panel settings-card"><h2>Dívidas e metas com prazo</h2><p>Cadastre apenas compromissos ainda não incluídos no orçamento. As parcelas e o valor restante das metas entram automaticamente nas despesas do mês e na projeção pós-aposentadoria quando você escolhe usar o orçamento. Não alteram o saldo realizado das contas.</p><p>Dívidas usam PRICE ou SAC, juros efetivos anuais, tarifas e amortizações extras informados por você. A primeira parcela vence na data informada. Em metas, o valor já reservado reduz o desembolso futuro e deve estar fora do patrimônio investido para evitar dupla contagem.</p>
  ${state.valuesHidden ? '' : `<details class="disclosure"><summary>Cadastrar ou editar compromisso</summary><form data-commitment-form><input type="hidden" name="id" /><div class="form-grid form-grid--two">${field('name', 'Nome', 'text', 'maxlength="60"')}<label class="form-field"><span>Tipo</span><select name="kind"><option value="debt">Dívida</option><option value="goal">Meta</option></select></label><label class="form-field"><span>Categoria da despesa</span><select name="categoryId">${expenseCategoryOptions('debt')}</select><small>Ex.: financiamento do imóvel em Moradia, meta de viagem em Viagens.</small></label>${field('amount', 'Principal da dívida ou valor da meta', 'number', 'min="0.01" max="1000000000" step="0.01"')}${field('date', 'Primeira parcela ou prazo da meta', 'date')}<label class="form-field"><span>Moeda</span><select name="currency">${Object.keys(currencies).map(code => `<option ${code === state.currency ? 'selected' : ''}>${code}</option>`).join('')}</select></label>${field('installments', 'Número de parcelas, somente dívida', 'number', 'min="1" max="600" value="12"')}${field('annualRate', 'Juros efetivos anuais (%), somente dívida', 'number', 'min="0" max="100" step="0.01" value="0"')}${field('saved', 'Já reservado fora da Carteira, somente meta', 'number', 'min="0" max="1000000000" step="0.01" value="0"')}</div>${debtExtraFields()}<div class="wizard-actions"><button class="button button--primary">Salvar compromisso</button><button class="button button--secondary" type="reset">Limpar</button></div></form></details>`}
  <div class="budget-entry-list">${(state.cashFlow.commitments || []).map(item => `<article><span>${escapeHtml(item.name)} · ${item.kind === 'debt' ? `${item.installments} parcelas, primeira em ${item.date}` : `Meta até ${item.date}`} · ${money(item.amount, item.currency)}</span>${item.kind === 'debt' ? `<span>Total de juros: ${money(debtSchedule(item).reduce((sum, row) => sum + row.interest, 0), item.currency)}</span>` : ''}${state.valuesHidden ? '' : `<button class="button button--secondary" data-commitment-edit="${item.id}">Editar</button>`}<button class="button button--secondary" data-commitment-remove="${item.id}">Excluir</button>${renderDebtDetails(item, { month: calendarView.month, valuesHidden: state.valuesHidden })}</article>`).join('') || '<p>Nenhum compromisso cadastrado.</p>'}</div></section>`
}
