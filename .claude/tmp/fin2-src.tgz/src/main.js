import { openReviewTarget } from './app/review-navigation.js'
import { focusSaveCopy } from './features/profile/data-overview.js'
import { bindFinancialValueLayout } from './shared/financial-value-layout.js'
import { bindNavigationMenu } from './app/navigation.js'
import { bindMoneyInputs, enhanceMoneyInputs, readMoneyFormData, setFormFieldValue, parseMoney } from './shared/money-input.js'
import { bindWealthCallouts } from './shared/wealth-callout.js'
import { flashRecalculation } from './shared/recalc-indicator.js'
import { appLayout } from './app/layout.js'
import { parseAnnualRealReturns, formatAnnualRealReturns } from './domain/investment-returns.js'
import { renderViability, saveViability } from './features/plan/viability.js'
import { renderConsortia, guideConsortiumForm, saveConsortium, consortiumView } from './features/cash-flow/consortia.js'
import { renderRisk, renderMonthlyRisk, startRisk, cancelRisk, riskSettingsFromForm } from './features/plan/risk.js'
import { guideCommitmentForm, guideMovementForm } from './app/planning-forms.js'
import { ownedStorage } from './app/owned-storage.js'
import { renderPostRetirement } from './features/plan/post-retirement.js'
import { validateDecumulation } from './domain/post-retirement.js'
import { renderCalendar, calendarView, saveCommitment } from './features/cash-flow/calendar.js'
import { expenseImpactView, resetExpenseImpact, renderExpenseImpact, calculateExpenseImpact, renderExpenseImpactResult } from './features/cash-flow/expense-impact.js'
import { paymentView, bindPaymentDialog } from './features/cash-flow/payments.js'
import { linkCalendarPayment, unlinkCalendarPayment } from './domain/calendar-payments.js'
import { variableView } from './features/dashboard/variable-contributions.js'
import { guideBudgetForm, showFormError } from './app/form-guidance.js'
import { changeAccounts, reconcileLedgerMovement, linkMovementBudget } from './app/accounts.js'
import { updatePortfolioFromAccount } from './app/portfolio-link.js'
import { recordReconciliation } from './domain/ledger-links.js'
import { prepareLedgerStatement, ledgerStatementView } from './features/accounts/statement-review.js'
import { renderAccounts } from './features/accounts/accounts.js'
import { previewReconciliation, reconciliationView } from './features/accounts/reconciliation.js'
import { canRenderFinancialPage, closeLocalPlan, openLocalPlan, isLocalPlanOpen, localLockKey, isPublicPage } from './app/local-access.js'
import { renderWelcome } from './features/welcome/welcome.js'
import { renderGuidedPlan } from './features/welcome/guided-plan.js'
import { beginGuidedPlan, saveGuidedAssets, saveGuidedGoal, saveGuidedBudget } from './app/guided-plan.js'
import { timelineView } from './features/cash-flow/timeline.js'
import { submitPortfolioCurrencyScenario, clearPortfolioScenarios } from './features/cash-flow/portfolio-currency.js'
import { currencyExplorer, loadCurrencyHistory, renderCurrencyExplorer } from './features/cash-flow/currency-explorer.js'
import { dataHistory, recordDataOperation } from './app/data-history.js'
import {
  addCashFlowItem,
  selectPlanOwner,
  copyGuestPlanToAccount,
  addCustomCategory,
  addScenario,
  deleteLocalData,
  importCashFlowItems,
  loadScenario,
  removeInvestment,
  removeCashFlowItem,
  removeScenario,
  replaceFinancialData,
  resetState,
  saveState,
  setChartRange,
  setCashFlowReferenceMonth,
  setBudgetRetirementMonth,
  setCurrency,
  state,
  toggleValues,
  toggleReminder,
  updatePlan,
  updateCashFlow,
  updateCashFlowItem,
  upsertInvestment,
  setTargetAllocation,
  setCurrencyTrends,
  setMigrationResolved
} from './app/state.js'
import {
  deleteRemoteState,
  loadRemoteState,
  loadSyncState,
  resetSyncState,
  saveRemoteState,
  syncState
} from './app/sync-state.js'
import { calculateMultiCurrencyCashFlow, retirementContributionSchedules } from './domain/cash-flow.js'
import { projectRetirementWithSchedules } from './domain/retirement.js'
import { renderContent } from './features/content/content.js'
import { renderDashboard } from './features/dashboard/dashboard.js'
import { renderWealth } from './features/wealth/wealth.js'
import { renderCashFlow, renderBudgetEntries, updateBudgetEntryResults } from './features/cash-flow/cash-flow.js'
import { budgetEntriesView, resetBudgetEntriesView, readBudgetFilters } from './features/cash-flow/budget-entries-view.js'
import { renderPlan } from './features/plan/plan.js'
import { renderProfile } from './features/profile/profile.js'
import { renderDeletedState, renderPrivacy } from './features/privacy/privacy.js'
import {
  renderSimulationResult,
  renderSimulations
} from './features/simulations/simulations.js'
import { formatCurrency, parseNumber, percentInputValue, privateCurrency } from './shared/formatters.js'
import { serializeExportableState, storageKeys } from './app/state-storage.js'
import { parseFinappImport, mergeFinappImport } from './domain/finapp-import.js'
import { renderFinappReconciliation } from './features/profile/finapp-review.js'
import { bindPlanningChartInteractions } from './shared/planning-chart-interactions.js'
import { cashFlowChartView } from './shared/cash-flow-line-chart.js'
import { savePropertySolvencyPreference } from './app/property-solvency.js'

const finappPreviews = new WeakMap()
import { saveAnnualPlanning } from './features/plan/annual-planning.js'
import { planningHorizon } from './domain/planning-horizon.js'
import {
  authState,
  loadAuthState,
  login,
  logout,
  recoverAccount,
  registerAccount,
  updatePassword
} from './app/auth-state.js'
import {
  renderLogin,
  renderNewPassword,
  renderRecovery,
  renderRegister
} from './features/auth/auth.js'
import { renderPremium } from './features/premium/premium.js'
import { allocationView, renderInvestments } from './features/investments/investments.js'
import { trackProductEvent } from './app/product-events.js'
import { categoryById } from './data/cash-flow-categories.js'
import { loadExchangeRates } from './app/exchange-rate-state.js'
import { inspectStatementText, reviewStatementImport } from './domain/statement-import.js'

import { configureLocalAccess, selectStorageProvider } from './app/auth-state.js'
import { syncConsentVersion } from './shared/sync-contract.js'
import { scenarioEditor, simulationContext, simulationCashFlow, simulationInputFromData, clearScenarioEditor, editScenario } from './features/simulations/scenario-editor.js'
import { simulationSchedules } from './features/simulations/simulations.js'
import { updateScenario } from './app/state.js'
import { inspectSavedPlan, clearSyncComparison } from './features/profile/sync-comparison.js'
import { confirmProjectionAssumption } from './app/projection-confirmations.js'
import { statementHistoryView, resetStatementHistoryView } from './features/statements/history.js'
import { saveStatementAnalysis, deleteStatementAnalysis, applyStatementRecurrences } from './app/statement-history.js'
import { compareStatementPeriods } from './domain/statement-history.js'
import { budgetOwnerView } from './shared/household-owner.js'
import { renderStatements, readStatementAnalysis } from './features/statements/statements.js'
import { bindMonthlyHints, updateMonthlyHint } from './app/monthly-hint.js'
import { bindPageTabs, revealInPageTab } from './shared/page-tabs.js'
import { classVolatility } from './domain/risk-plan.js'
import { correlationPresets, defaultClassCorrelations } from './domain/class-correlation.js'

bindMoneyInputs(document)
const app = document.querySelector('#app')
bindNavigationMenu(app)
bindWealthCallouts(app)
let disposeValueLayout = () => {}
const toastRegion = document.querySelector('#toast-region')
let statementReviewState = null
const storageCopyLabel = () => (authState.storageProvider || authState.provider) === 'local' ? 'cópia no banco deste computador' : 'cópia remota'

function switchSessionPlan() {
  resetExpenseImpact()
  paymentView.selectedKey = null
  paymentView.filter = 'all'
  disposeValueLayout()
  cashFlowChartView.selectedYear = null
  cashFlowChartView.basis = 'real'
  cashFlowChartView.wealth = 'essential'
  cashFlowChartView.flow = 'budget'
  timelineView.selectedYear = null
  cancelRisk(true)
  clearScenarioEditor()
  budgetOwnerView.selected = 'all'
  resetBudgetEntriesView()
  resetStatementHistoryView()
  clearSyncComparison()
  consortiumView.preview = null
  closeLocalPlan()
  statementReviewState = null
  reconciliationView.input = null
  ledgerStatementView.preview = null
  clearPortfolioScenarios()
  app.replaceChildren()
  selectPlanOwner(authState.authenticated ? authState.user.id : null)
  resetSyncState()
}

const routes = {
  '/consorcios': renderConsortia,
  '/riscos': renderRisk,
  '/riscos-mensais': renderMonthlyRisk,
  '/viabilidade': renderViability,
  '/apos-aposentadoria': renderPostRetirement,
  '/calendario': renderCalendar,
  '/contas': renderAccounts,
  '/cambio': renderCurrencyExplorer,
  '/': renderDashboard,
  '/plano': renderPlan,
  '/carteira': renderInvestments,
  '/patrimonio': renderWealth,
  '/extratos': renderStatements,
  '/fluxo-caixa': renderCashFlow,
  '/orcamento': () => renderBudgetEntries(statementReviewView()),
  '/simulacoes': renderSimulations,
  '/conteudos': renderContent,
  '/perfil': renderProfile,
  '/privacidade': renderPrivacy,
  '/entrar': renderLogin,
  '/cadastro': renderRegister,
  '/recuperar-senha': renderRecovery,
  '/nova-senha': renderNewPassword,
  '/premium': renderPremium
}

function currentPath() {
  const path = window.location.pathname.replace(/\/$/, '')
  return path || '/'
}

function captureSimulationForm() {
  const form = document.querySelector('[data-simulation-form]')
  if (!form) return null
  return Object.fromEntries(new FormData(form).entries())
}

function restoreSimulationForm(values) {
  if (!values) return
  const form = document.querySelector('[data-simulation-form]')
  if (!form) return
  for (const [name, value] of Object.entries(values)) {
    const field = form.elements.namedItem(name)
    if (field) setFormFieldValue(field, value)
  }
}

function render({ focusMain = false, resetSimulation = false, indicateRecalculation = true } = {}) {
  disposeValueLayout()
  if (!sessionReady) { app.innerHTML = '<main class="page-shell"><p role="status">Verificando a sessão antes de abrir seus dados…</p></main>'; return }
  if (indicateRecalculation) flashRecalculation()
  const pathname = currentPath()
  const simulationValues = pathname === '/simulacoes' && !resetSimulation ? captureSimulationForm() : null
  const selectedRenderer = pathname === '/inicio' || !canRenderFinancialPage(pathname) ? renderWelcome : pathname.startsWith('/construir/') ? () => renderGuidedPlan(pathname.split('/')[2]) : routes[pathname] || renderDashboard
  const pageRenderer = state.dataDeleted && canRenderFinancialPage(pathname) && !isPublicPage(pathname) && pathname !== '/perfil'
    ? renderDeletedState
    : selectedRenderer
  app.innerHTML = appLayout(pageRenderer() + (isLocalPlanOpen() && !isPublicPage(pathname) && !state.dataDeleted ? renderExpenseImpact() : ''), pathname)
  bindPlanningChartInteractions(app)
  bindPaymentDialog(app)
  enhanceMoneyInputs(app, { hidden: state.valuesHidden })
  restoreSimulationForm(simulationValues)
  document.querySelectorAll('[data-guided-budget], [data-cash-item-form], [data-cash-item-edit-form]').forEach(form => guideBudgetForm(form, state.customCategories))
  guideCommitmentForm(document.querySelector('[data-commitment-form]'))
  guideConsortiumForm(document.querySelector('[data-consortium-form]'))
  guideMovementForm(document.querySelector('[data-movement-form]'), state.cashFlow.ledger.accounts)
  document.body.classList.toggle('values-hidden', state.valuesHidden)
  disposeValueLayout = bindFinancialValueLayout(app, { hidden: state.valuesHidden })

  document.querySelectorAll('[data-product-impression]').forEach((element) => {
    const eventName = element.dataset.productImpression
    const impressionKey = `${pathname}:${eventName}:${state.isDemo}:${authState.authenticated}`
    if (trackedProductImpressions.has(impressionKey)) return
    trackedProductImpressions.add(impressionKey)
    trackProductEvent(eventName)
  })

  if (focusMain) {
    document.querySelector('#conteudo')?.focus({ preventScroll: true })
  }
  if (lastReviewLocation !== window.location.href && isLocalPlanOpen() && !state.valuesHidden && !state.dataDeleted) {
    lastReviewLocation = window.location.href
    openReviewTarget(app, window.location.href, { openBudget: openCashItemDialog, onMissing: showToast })
  }
}

const trackedProductImpressions = new Set()
let lastReviewLocation = null

function navigate(href) {
  resetExpenseImpact()
  if (href !== '/simulacoes') clearScenarioEditor()
  if (currentPath() !== href) window.history.pushState({}, '', href)
  lastReviewLocation = null
  window.scrollTo({ top: 0, behavior: 'instant' })
  render({ focusMain: true, indicateRecalculation: false })
}

let toastTimer
function showToast(message) {
  window.clearTimeout(toastTimer)
  const toast = document.createElement('div')
  toast.className = 'toast'
  toast.textContent = String(message)
  toastRegion.replaceChildren(toast)
  toastTimer = window.setTimeout(() => {
    toastRegion.replaceChildren()
  }, 3200)
}

function simulationInputFromForm(form) {
  return simulationInputFromData(readMoneyFormData(form))
}

function showInvestmentStep(form, step) {
  form.querySelectorAll('[data-investment-step]').forEach((fieldset) => {
    fieldset.hidden = fieldset.dataset.investmentStep !== String(step)
  })
  const badge = form.querySelector('[data-investment-step-badge]')
  if (badge) badge.textContent = `${step} de 2`
}

// Shows fields only when they apply: release year for restricted balances and
// first contribution date for private pension plans.
function setInvestmentConditionalFields(form) {
  const restricted = form.elements.namedItem('liquidity').value === 'restricted'
  const pension = form.elements.namedItem('assetClass').value === 'pension'
  const release = form.querySelector('[data-investment-release-field]')
  const pensionField = form.querySelector('[data-investment-pension-field]')
  if (release) {
    release.hidden = !restricted
    if (!restricted) form.elements.namedItem('investmentReleaseYear').value = ''
  }
  if (pensionField) {
    pensionField.hidden = !pension
    if (!pension) form.elements.namedItem('investmentAcquiredAt').value = ''
  }
}

function setInvestmentReturnFields(form) {
  const returnType = form.elements.namedItem('returnType').value
  const returnField = form.querySelector('[data-investment-return-field]')
  const indexField = form.querySelector('[data-investment-index-field]')
  const returnInput = form.elements.namedItem('investmentReturn')
  const indexInput = form.elements.namedItem('investmentIndexRate')
  const label = form.querySelector('[data-investment-return-label]')
  const hint = form.querySelector('[data-investment-return-hint]')
  const usesReturn = returnType !== 'default'
  const usesIndex = returnType === 'cdi'
  const settings = {
    real: ['Retorno real anual esperado', 'Taxa acima da inflação, informada por você.', -99, 100],
    nominal: ['Retorno nominal anual esperado', 'A inflação do plano será descontada desta taxa.', -99, 100],
    cdi: ['Percentual do CDI', 'Exemplo: informe 110 para um investimento de 110% do CDI.', 0, 300],
    ipca: ['Taxa real acima do IPCA', 'Exemplo: em IPCA + 6%, informe 6.', -99, 100]
  }
  returnField.hidden = !usesReturn
  returnInput.required = usesReturn
  returnInput.disabled = !usesReturn
  indexField.hidden = !usesIndex
  indexInput.required = usesIndex
  indexInput.disabled = !usesIndex
  if (usesReturn) {
    const [labelText, hintText, minimum, maximum] = settings[returnType]
    label.textContent = labelText
    hint.textContent = hintText
    returnInput.min = String(minimum)
    returnInput.max = String(maximum)
  }
}

function statementReviewView() {
  if (!statementReviewState) return null
  const review = reviewStatementImport(statementReviewState.inspection, {
    mapping: statementReviewState.mapping,
    defaultCurrency: state.currency,
    customCategories: state.customCategories,
    existingItems: state.cashFlow.items
  })
  const rows = review.rows.map((row) => ({
    ...row,
    selected: Boolean(row.item) && !row.duplicate && !statementReviewState.excludedRows.has(row.rowNumber)
  }))
  const selectedCount = rows.filter((row) => row.selected).length
  const availableSlots = Math.max(100 - state.cashFlow.items.length, 0)
  return {
    ...review,
    rows,
    headers: statementReviewState.inspection.headers,
    fileName: statementReviewState.fileName,
    totalRows: statementReviewState.inspection.totalRows,
    selectedCount,
    duplicateCount: rows.filter((row) => row.duplicate).length,
    invalidCount: rows.filter((row) => row.error).length,
    availableSlots,
    overLimit: selectedCount > availableSlots
  }
}

function openStatementReviewDialog() {
  const dialog = document.querySelector('[data-statement-review-dialog]')
  if (!dialog) return
  if (typeof dialog.showModal === 'function') dialog.showModal()
  else dialog.setAttribute('open', '')
}

function closeStatementReview() {
  statementReviewState = null
  render()
}

function reserveInputFromForm(form) {
  const data = readMoneyFormData(form)
  return {
    currentEmergencyReserve: parseNumber(data.get('currentEmergencyReserve')),
    emergencyReserveTarget: parseNumber(data.get('emergencyReserveTarget')),
    reserveBuildMonths: Math.round(parseNumber(data.get('reserveBuildMonths')))
  }
}

function cashItemInputFromForm(form) {
  const category = categoryById(form.elements.namedItem('categoryId').value, state.customCategories)
  if (!category) throw new TypeError('Selecione uma categoria válida.')
  const recordKind = form.elements.namedItem('recordKind').value
  return {
    type: category.type,
    categoryId: category.id,
    description: form.elements.namedItem('description').value,
    householdOwner: form.elements.namedItem('householdOwner')?.value || 'unspecified',
    amount: parseMoney(form.elements.namedItem('amount').value),
    currency: form.elements.namedItem('currency').value,
    frequency: recordKind === 'actual' ? 'occasional' : form.elements.namedItem('frequency').value,
    startDate: form.elements.namedItem('startDate').value,
    endDate: form.elements.namedItem('endMode').value === 'date' ? form.elements.namedItem('endDate').value : null,
    endMode: form.elements.namedItem('endMode').value,
    recordKind
  }
}

function syncCashItemRecordFields(form) {
  if (!form) return
  const isActual = form.elements.namedItem('recordKind').value === 'actual'
  const frequency = form.elements.namedItem('frequency')
  const startDate = form.elements.namedItem('startDate')
  if (isActual) frequency.value = 'occasional'
  frequency.disabled = isActual
  startDate.required = isActual
}

function openCashItemDialog(id) {
  const item = state.cashFlow.items.find((candidate) => candidate.id === id)
  const dialog = document.querySelector('[data-cash-item-dialog]')
  const form = dialog?.querySelector('[data-cash-item-edit-form]')
  if (!item || !dialog || !form) throw new TypeError('Lançamento não encontrado.')
  form.elements.namedItem('itemId').value = item.id
  for (const field of ['categoryId', 'description', 'amount', 'currency', 'frequency', 'startDate', 'endDate', 'endMode', 'recordKind', 'householdOwner']) {
    const input = form.elements.namedItem(field)
    if (input) setFormFieldValue(input, item[field] ?? (field === 'householdOwner' ? 'unspecified' : ''))
  }
  const imported = item.source === 'txt'
  form.elements.namedItem('recordKind').disabled = imported
  form.querySelector('[data-cash-edit-source]').textContent = imported
    ? 'Item importado. A origem e a classificação como realizado são preservadas.'
    : 'Item manual. Você pode alterar todos os campos.'
  syncCashItemRecordFields(form)
  guideBudgetForm(form, state.customCategories)
  updateMonthlyHint(dialog.querySelector('form'))
  if (typeof dialog.showModal === 'function') dialog.showModal()
  else dialog.setAttribute('open', '')
}

function closeCashItemDialog() {
  const dialog = document.querySelector('[data-cash-item-dialog]')
  if (!dialog) return
  if (typeof dialog.close === 'function') dialog.close()
  else dialog.removeAttribute('open')
}

function openAnnualGoalDialog(id) {
  const row = (state.cashFlow.annualGoals || []).find((candidate) => candidate.id === id)
  const dialog = document.querySelector('[data-annual-goal-dialog]')
  const form = dialog?.querySelector('[data-annual-planning="annualGoals"]')
  if (!row || !dialog || !form) throw new TypeError('Provisão anual não encontrada.')
  form.reset()
  for (const [key, value] of Object.entries(row)) {
    const field = form.elements.namedItem(key)
    if (field) setFormFieldValue(field, key === 'realGrowth' ? value * 100 : value)
  }
  const categoryField = form.elements.namedItem('categoryId')
  if (categoryField) categoryField.value = row.categoryId && [...categoryField.options].some(option => option.value === row.categoryId) ? row.categoryId : 'other-expense'
  updateMonthlyHint(dialog.querySelector('form'))
  if (typeof dialog.showModal === 'function') dialog.showModal()
  else dialog.setAttribute('open', '')
}

function closeAnnualGoalDialog() {
  const dialog = document.querySelector('[data-annual-goal-dialog]')
  if (!dialog) return
  if (typeof dialog.close === 'function') dialog.close()
  else dialog.removeAttribute('open')
}

function refreshBudgetResults() {
  updateBudgetEntryResults(app)
}

function finishBudgetSave(message, id = null) {
  render()
  const edit = id ? [...app.querySelectorAll('[data-edit-cash-item]')].find(button => button.dataset.editCashItem === id) : null
  const target = edit || app.querySelector('[data-new-cash-item]:not(:disabled)') || app.querySelector('[data-budget-filters] [name="search"]')
  target?.focus({ preventScroll: true })
  showToast(`${message}${id && !edit ? ' Para localizar o registro, limpe os filtros e selecione Todos os períodos.' : ''}`)
}

function currentRetirementSchedules() {
  return retirementContributionSchedules(
    state.cashFlow,
    state.currency,
    state.exchangeRates,
    state.customCategories
  )
}

function exportData() {
  try {
    const file = new Blob([serializeExportableState(state)], {
      type: 'application/json'
    })
    const url = URL.createObjectURL(file)
    const link = document.createElement('a')
    link.href = url
    link.download = 'aposenta-plus-dados.json'
    link.click()
    URL.revokeObjectURL(url)
    recordDataOperation('export')
    showToast('Arquivo preparado com os dados do plano e do fluxo de caixa.')
  } catch {
    showToast('Não foi possível exportar seus dados. Tente novamente.')
  }
}

document.addEventListener('click', async (event) => {
  if (!sessionReady) { event.preventDefault(); return }
  const reviewMonth = event.target.closest('[data-review-month-records]')
  if (reviewMonth) {
    const kind = reviewMonth.dataset.reviewMonthRecords
    if (!['actual', 'planned'].includes(kind)) return
    resetBudgetEntriesView()
    budgetEntriesView.recordKind = kind
    navigate('/orcamento')
    app.querySelector('[data-budget-filters] [name="recordKind"]')?.focus({ preventScroll: true })
    return
  }
  const expenseImpact = event.target.closest('[data-expense-impact]')
  if (expenseImpact) {
    if (state.valuesHidden) return
    resetExpenseImpact()
    expenseImpactView.input = { itemId: expenseImpact.dataset.expenseImpact, percent: 10, startYear: Number(expenseImpact.dataset.impactYear), targetAge: Number(expenseImpact.dataset.impactAge) }
    const year = String(expenseImpact.dataset.impactYear)
    cashFlowChartView.selectedYear = year
    timelineView.selectedYear = year
    render()
    const dialog = app.querySelector('[data-expense-impact-dialog]')
    if (dialog) {
      dialog.addEventListener('close', () => {
        const trigger = [...app.querySelectorAll('[data-expense-impact]')].find(button => button.dataset.expenseImpact === expenseImpactView.input?.itemId && button.dataset.impactYear === year)
        resetExpenseImpact()
        trigger?.focus({ preventScroll: true })
      }, { once: true })
      dialog.showModal()
    }
    return
  }
  if (event.target.closest('[data-expense-impact-close]')) {
    app.querySelector('[data-expense-impact-dialog]')?.close()
    return
  }
  const paymentOpen = event.target.closest('[data-payment-open]')
  if (paymentOpen) {
    if (state.valuesHidden) return
    paymentView.selectedKey = paymentOpen.dataset.paymentOpen
    render()
    app.querySelector('[data-payment-dialog]')?.showModal()
    return
  }
  if (event.target.closest('[data-payment-close]')) {
    app.querySelector('[data-payment-dialog]')?.close()
    return
  }
  const paymentUnlink = event.target.closest('[data-payment-unlink]')
  if (paymentUnlink) {
    if (state.valuesHidden) return
    try {
      updateCashFlow({ paymentMatches: unlinkCalendarPayment(state.cashFlow, { eventKey: paymentUnlink.dataset.paymentUnlink, movementId: paymentUnlink.dataset.paymentMovement }) })
      paymentView.selectedKey = null
      paymentView.filter = 'all'
      render()
      app.querySelector('[data-payment-filter]')?.focus({ preventScroll: true })
      showToast('Associação desfeita. O movimento e os demais vínculos foram preservados.')
    } catch (error) { showToast(error.message) }
    return
  }
  if (event.target.closest('[data-new-cash-item]')) {
    const dialog = app.querySelector('[data-new-cash-item-dialog]')
    if (dialog) {
      if (budgetEntriesView.recordKind === 'actual') {
        const form = dialog.querySelector('[data-cash-item-form]')
        form.elements.namedItem('recordKind').value = 'actual'
        form.elements.namedItem('frequency').value = 'occasional'
        guideBudgetForm(form, state.customCategories)
      }
      dialog.showModal()
      dialog.querySelector('[name="categoryId"]')?.focus()
    }
    return
  }
  if (event.target.closest('[data-close-new-cash-item]')) {
    app.querySelector('[data-new-cash-item-dialog]')?.close()
    return
  }
  if (event.target.closest('[data-open-budget-import]')) {
    const section = app.querySelector('.statement-import')
    revealInPageTab(app, section)
    if (section) { section.open = true; section.querySelector('summary')?.focus(); section.scrollIntoView({ block: 'start' }) }
    return
  }
  if (event.target.closest('[data-reset-budget-filters]')) {
    resetBudgetEntriesView()
    budgetEntriesView.period = 'all'
    render()
    app.querySelector('[data-budget-filters] [name="search"]')?.focus({ preventScroll: true })
    return
  }
  const solvencyYear = event.target.closest('[data-solvency-year]')
  if (solvencyYear) {
    const view = solvencyYear.closest('[data-cash-flow-line-view]')
    const control = view?.querySelector('[data-cash-flow-year], [data-chart-year]')
    const index = Array.from(control?.options || []).findIndex(option => option.textContent.startsWith(solvencyYear.dataset.solvencyYear))
    if (index >= 0) {
      control.value = String(index)
      control.dispatchEvent(new Event('change', { bubbles: true }))
      control.focus({ preventScroll: true })
      control.scrollIntoView({ block: 'center' })
    }
    return
  }
  const annualAction = event.target.closest('[data-annual-edit], [data-annual-remove]')
  if (annualAction) {
    const kind = annualAction.dataset.annualKind
    if (!['annualGoals', 'nonFinancialAssets'].includes(kind)) return
    const id = annualAction.dataset.annualEdit || annualAction.dataset.annualRemove
    const row = (state.cashFlow[kind] || []).find(item => item.id === id)
    if (!row) return
    if (annualAction.dataset.annualRemove) {
      if (window.confirm(`Excluir ${row.name} do plano?`)) { updateCashFlow({ [kind]: state.cashFlow[kind].filter(item => item.id !== id) }); render() }
    } else {
      const form = document.querySelector(`[data-annual-planning="${kind}"]`)
      if (!form) return
      form.reset()
      for (const [key, value] of Object.entries(row)) {
        const field = form.elements.namedItem(key)
        if (field && field.type !== 'checkbox') setFormFieldValue(field, key === 'realGrowth' ? value * 100 : value)
      }
      if (kind === 'annualGoals' && form.elements.namedItem('categoryId')) form.elements.namedItem('categoryId').value = row.categoryId || 'other-expense'
      if (kind === 'nonFinancialAssets') {
        form.elements.namedItem('category').value = row.category || 'unclassified'
        form.elements.namedItem('includeInSolvency').checked = row.includeInSolvency !== false
        form.querySelector('[data-property-setting]').hidden = row.category !== 'real-estate'
      }
      form.closest('details').open = true
      form.scrollIntoView({ block: 'center' })
    }
    return
  }
  if (event.target.closest('[data-risk-cancel]')) { cancelRisk(); render(); return }
  const consortiumEdit = event.target.closest('[data-consortium-edit]')
  if (consortiumEdit) {
    const item = (state.cashFlow.consortia || []).find(row => row.id === consortiumEdit.dataset.consortiumEdit)
    const form = document.querySelector('[data-consortium-form]')
    if (item && form) {
      for (const [key, value] of Object.entries(item)) {
        const field = form.elements.namedItem(key)
        if (field) setFormFieldValue(field, ['annualAdjustment', 'creditReturn', 'assetReturn'].includes(key) ? value * 100 : value ?? '')
      }
      form.elements.namedItem('confirmed').checked = false
      guideConsortiumForm(form)
      form.elements.namedItem('name').focus()
      form.scrollIntoView({ block: 'start', behavior: 'smooth' })
    }
    return
  }
  const consortiumRemove = event.target.closest('[data-consortium-remove]')
  if (consortiumRemove) {
    if (window.confirm('Excluir o consórcio desta projeção? Parcelas e posição vinculada deixarão de entrar nos cálculos. Contas realizadas não serão alteradas.')) {
      updateCashFlow({ consortia: state.cashFlow.consortia.filter(row => row.id !== consortiumRemove.dataset.consortiumRemove) }); render()
    }
    return
  }
  if (event.target.closest('[data-clear-ledger-statement]')) { ledgerStatementView.preview = null; render(); return }
  const unreconcile = event.target.closest('[data-unreconcile]')
  if (unreconcile) {
    if (window.confirm('Desfazer esta conciliação? O movimento será mantido.')) {
      let ledger = structuredClone(state.cashFlow.ledger)
      const movement = ledger.movements.find(row => row.id === unreconcile.dataset.unreconcile)
      if (movement) ledger = recordReconciliation(ledger, movement.id, (movement.reconciliations || []).filter(row => row.accountId === unreconcile.dataset.reconcileAccount), 'revoked')
      if (movement) movement.reconciliations = (movement.reconciliations || []).filter(row => row.accountId !== unreconcile.dataset.reconcileAccount)
      updateCashFlow({ ledger }); render()
    }
    return
  }
  const unlinkInvestment = event.target.closest('[data-unlink-investment]')
  if (unlinkInvestment) {
    const ledger = structuredClone(state.cashFlow.ledger)
    const account = ledger.accounts.find(row => row.id === unlinkInvestment.dataset.unlinkInvestment)
    if (account) { delete account.investmentId; delete account.investmentSyncDate }
    updateCashFlow({ ledger }); render()
    return
  }
  const commitmentEdit = event.target.closest('[data-commitment-edit]')
  if (commitmentEdit) {
    const item = state.cashFlow.commitments.find(row => row.id === commitmentEdit.dataset.commitmentEdit)
    const form = document.querySelector('[data-commitment-form]')
    if (item && form) {
      for (const [key, value] of Object.entries(item)) { const field = form.elements.namedItem(key); if (field) setFormFieldValue(field, key === 'annualRate' ? value * 100 : key === 'extraPayments' ? value.map(row => `${row.month};${row.amount.toFixed(2)}`).join('\n') : value) }
      if (form.elements.namedItem('categoryId')) form.elements.namedItem('categoryId').value = item.categoryId || (item.kind === 'debt' ? 'debt' : 'other-expense')
      form.closest('details').open = true
      guideCommitmentForm(form)
      form.elements.namedItem('name').focus()
    }
    return
  }
  const commitmentRemove = event.target.closest('[data-commitment-remove]')
  if (commitmentRemove) {
    if (window.confirm('Excluir este compromisso e suas despesas futuras?')) { updateCashFlow({ commitments: state.cashFlow.commitments.filter(item => item.id !== commitmentRemove.dataset.commitmentRemove) }); render() }
    return
  }
  if (event.target.closest('[data-copy-guest]')) {
    if (!window.confirm('Copiar o plano de visitante para esta conta? A cópia de visitante será mantida. Copie somente dados que pertencem a você.')) return
    try { copyGuestPlanToAccount(); render(); showToast('Plano copiado. A cópia de visitante continua separada.') } catch (error) { showToast(error.message) }
    return
  }
  const ledgerEdit = event.target.closest('[data-account-edit], [data-movement-edit]')
  if (ledgerEdit) {
    const isAccount = ledgerEdit.hasAttribute('data-account-edit')
    const item = (isAccount ? state.cashFlow.ledger.accounts : state.cashFlow.ledger.movements).find(item => item.id === (ledgerEdit.dataset.accountEdit || ledgerEdit.dataset.movementEdit))
    const form = document.querySelector(isAccount ? '[data-account-form]' : '[data-movement-form]')
    if (!item || !form) return
    form.reset()
    for (const [key, value] of Object.entries(item)) {
      const field = form.elements.namedItem(key)
      if (field) setFormFieldValue(field, value ?? '')
    }
    form.querySelector('[data-ledger-edit-label]').textContent = isAccount ? 'Editando conta' : 'Editando movimento'
    if (!isAccount) guideMovementForm(form, state.cashFlow.ledger.accounts)
    form.closest('details').open = true
    form.scrollIntoView({ block: 'center', behavior: 'smooth' })
    form.querySelector('input:not([type="hidden"]), select')?.focus({ preventScroll: true })
    return
  }
  if (event.target.closest('[data-ledger-cancel]')) {
    const form = event.target.closest('form')
    form.reset()
    form.elements.namedItem('id').value = ''
    form.querySelector('[data-ledger-edit-label]').textContent = 'Novo registro'
    form.querySelector('[data-form-error]')?.remove()
    return
  }
  const accountRemove = event.target.closest('[data-account-remove], [data-movement-remove]')
  if (accountRemove) {
    if (!window.confirm('Excluir este registro? O saldo será recalculado.')) return
    try { changeAccounts(accountRemove.hasAttribute('data-account-remove') ? 'delete-account' : 'delete-movement', accountRemove.dataset.accountRemove || accountRemove.dataset.movementRemove); render() } catch (error) { showToast(error.message) }
    return
  }
  if (event.target.closest('[data-open-local], [data-start-guided]')) {
    const guided = Boolean(event.target.closest('[data-start-guided]'))
    if (guided && (state.isDemo || state.dataDeleted) && !window.confirm('Começar sem valores de demonstração? Receitas, despesas, patrimônio e aportes de exemplo serão substituídos por zero. Revise as premissas no primeiro passo.')) return
    if (guided) beginGuidedPlan()
    openLocalPlan()
    navigate(guided ? '/construir/objetivo' : '/')
    return
  }
  if (event.target.closest('[data-close-local]')) {
    cancelRisk(true)
    closeLocalPlan()
    try { localStorage.setItem(localLockKey, String(Date.now())) } catch {}
    navigate('/inicio')
    return
  }
  if (event.target.closest('[data-load-currency-history]')) {
    const pending = loadCurrencyHistory()
    render()
    await pending
    render()
    return
  }
  if (event.target.closest('[data-export-history]')) {
    const url = URL.createObjectURL(new Blob([JSON.stringify(dataHistory.read().events, null, 2)], { type: 'application/json' }))
    const link = document.createElement('a')
    link.href = url
    link.download = 'aposenta-plus-operacoes.json'
    link.click()
    URL.revokeObjectURL(url)
    showToast('Arquivo de operações preparado.')
    return
  }
  const recovery = event.target.closest('[data-recover-version]')
  if (recovery) {
    if (!window.confirm('Recuperar esta versão e substituir os dados atuais?')) return
    try {
      const candidate = dataHistory.snapshot(recovery.dataset.recoverVersion)
      dataHistory.checkpoint(state)
      replaceFinancialData(candidate)
      recordDataOperation('recover')
      render()
      showToast('Versão recuperada.')
    } catch (error) { showToast(error.message) }
    return
  }
  if (event.target.closest('[data-clear-history]')) {
    if (!window.confirm('Apagar o histórico e as versões de recuperação deste navegador?')) return
    try { dataHistory.clear(); render(); showToast('Histórico apagado.') }
    catch { showToast('Não foi possível apagar o histórico.') }
    return
  }
  const productEventTarget = event.target.closest('[data-product-event]')
  if (productEventTarget) trackProductEvent(productEventTarget.dataset.productEvent)

  if (event.target.closest('[data-open-save-copy]')) {
    event.preventDefault()
    focusSaveCopy(app)
    return
  }
  const routeLink = event.target.closest('[data-route]')
  if (routeLink) {
    event.preventDefault()
    navigate(routeLink.getAttribute('href'))
    return
  }

  if (event.target.closest('[data-toggle-values]')) {
    toggleValues()
    render()
    showToast(state.valuesHidden ? 'Valores ocultos.' : 'Valores visíveis.')
    return
  }

  if (event.target.closest('[data-auth-logout]')) {
    try {
      await logout()
      switchSessionPlan()
      closeLocalPlan()
      try { localStorage.setItem(localLockKey, String(Date.now())) } catch {}
      resetSyncState()
      navigate('/inicio')
      showToast('Sessão encerrada. Plano local fechado, sem apagar os dados.')
    } catch (error) {
      showToast(error.message)
    }
    return
  }

  if (event.target.closest('[data-sync-pull]')) {
    if (!window.confirm(`Substituir o plano, o fluxo de caixa e os cenários do navegador pela ${storageCopyLabel()}?`)) return
    try {
      const remote = await loadRemoteState()
      if (!state.dataDeleted) dataHistory.checkpoint(state)
      replaceFinancialData(remote.state)
      clearSyncComparison()
      recordDataOperation('restore')
      await loadSyncState()
      render()
      showToast(`${storageCopyLabel()} aplicada neste navegador.`)
    } catch (error) {
      recordDataOperation('restore', 'failure')
      showToast(error.message)
    }
    return
  }

  const compareCopyButton = event.target.closest('[data-compare-saved-plan]')
  if (compareCopyButton) {
    compareCopyButton.disabled = true
    try { await inspectSavedPlan(); render() }
    catch (error) { showToast(error.message) }
    finally { compareCopyButton.disabled = false }
    return
  }
  if (event.target.closest('[data-sync-refresh]')) {
    clearSyncComparison()
    await loadSyncState()
    render()
    showToast(syncState.available ? `Estado da ${storageCopyLabel()} atualizado.` : syncState.error)
    return
  }

  if (event.target.closest('[data-sync-delete]')) {
    if (!window.confirm(`Excluir a ${storageCopyLabel()}? Os dados do navegador serão mantidos.`)) return
    try {
      await deleteRemoteState()
      clearSyncComparison()
      recordDataOperation('remote_delete')
      render()
      showToast(`${storageCopyLabel()} e consentimento excluídos. Os dados do navegador foram mantidos.`)
    } catch (error) {
      showToast(error.message)
    }
    return
  }

  if (event.target.closest('[data-apply-sustainable-contribution]')) {
    const retirement = projectRetirementWithSchedules(state.plan, currentRetirementSchedules())
    const cashFlow = calculateMultiCurrencyCashFlow(
      state.cashFlow,
      state.currency,
      state.exchangeRates,
      retirement.requiredMonthlyContribution,
      state.customCategories
    )
    updatePlan({ monthlyContribution: cashFlow.sustainableContribution })
    render()
    showToast(`Aporte sustentável de ${formatCurrency(cashFlow.sustainableContribution, false, state.currency)} aplicado ao plano.`)
    return
  }

  if (event.target.closest('[data-apply-adjustment]')) {
    updatePlan({ monthlyContribution: Math.min(state.plan.monthlyContribution + 200, 4000) })
    render()
    showToast(`Novo aporte de ${formatCurrency(state.plan.monthlyContribution, false, state.currency)} salvo.`)
    return
  }

  const rangeButton = event.target.closest('[data-chart-range]')
  if (rangeButton) {
    setChartRange(rangeButton.dataset.chartRange)
    render()
    return
  }

  if (event.target.closest('[data-content-preview]')) {
    showToast('Conteúdo completo entra na próxima etapa do produto.')
    return
  }

  if (event.target.closest('[data-help]')) {
    showToast('A central de ajuda entra na próxima etapa do produto.')
    return
  }

  if (event.target.closest('[data-reminder]')) {
    toggleReminder()
    render()
    showToast(state.reminderEnabled ? 'Lembrete mensal ativado.' : 'Lembrete mensal desativado.')
    return
  }

  const nextInvestmentStep = event.target.closest('[data-next-investment-step]')
  if (nextInvestmentStep) {
    const form = nextInvestmentStep.closest('[data-investment-form]')
    const requiredNames = ['investmentName', 'assetClass', 'investmentAmount', 'investmentContribution', 'investmentReleaseYear']
    const valid = requiredNames.every((name) => form.elements.namedItem(name).reportValidity())
    if (valid) {
      showInvestmentStep(form, 2)
      form.elements.namedItem('returnType')?.focus()
    }
    return
  }

  const previousInvestmentStep = event.target.closest('[data-previous-investment-step]')
  if (previousInvestmentStep) {
    const form = previousInvestmentStep.closest('[data-investment-form]')
    showInvestmentStep(form, 1)
    form.elements.namedItem('investmentName').focus()
    return
  }

  const editInvestmentButton = event.target.closest('[data-edit-investment]')
  if (editInvestmentButton) {
    const investment = (state.plan.investments || []).find((item) => item.id === editInvestmentButton.dataset.editInvestment)
    const form = document.querySelector('[data-investment-form]')
    if (!investment || !form) return
    form.elements.namedItem('investmentId').value = investment.id
    form.elements.namedItem('investmentName').value = investment.name
    form.elements.namedItem('assetClass').value = investment.assetClass
    form.elements.namedItem('liquidity').value = investment.liquidity || 'unknown'
    form.elements.namedItem('exposureCurrency').value = investment.exposureCurrency || state.currency
    form.elements.namedItem('exposureShare').value = Math.round((investment.exposureShare ?? 1) * 100)
    form.elements.namedItem('region').value = investment.region || 'domestic'
    setFormFieldValue(form.elements.namedItem('investmentAmount'), investment.amount)
    setFormFieldValue(form.elements.namedItem('investmentContribution'), investment.monthlyContribution)
    setInvestmentConditionalFields(form)
    form.elements.namedItem('investmentAcquiredAt').value = investment.acquiredAt || ''
    form.elements.namedItem('investmentReleaseYear').value = state.plan.finappMethod?.releases?.find(row => row.investmentId === investment.id)?.year ?? ''
    form.elements.namedItem('returnType').value = investment.returnType
    form.elements.namedItem('investmentReturn').value = investment.returnValue === null ? '' : percentInputValue(investment.returnValue)
    form.elements.namedItem('investmentIndexRate').value = investment.indexAnnualRate === null ? '' : percentInputValue(investment.indexAnnualRate)
    form.elements.namedItem('investmentAnnualReturns').value = formatAnnualRealReturns(investment.annualRealReturns)
    form.elements.namedItem('investmentAnnualFee').value = investment.annualFee ? percentInputValue(investment.annualFee) : ''
    form.querySelector('[data-investment-form-title]').textContent = 'Revise os dados do investimento'
    form.querySelector('[data-investment-submit]').textContent = 'Salvar investimento'
    setInvestmentReturnFields(form)
    showInvestmentStep(form, 1)
    form.scrollIntoView({ behavior: 'smooth', block: 'start' })
    form.elements.namedItem('investmentName').focus({ preventScroll: true })
    return
  }

  const correlationPreset = event.target.closest('[data-correlation-preset]')
  if (correlationPreset) {
    const fields = correlationPreset.closest('[data-volatility-fields]')
    const preset = correlationPresets[correlationPreset.dataset.correlationPreset]
    if (fields && preset) for (const [pair, value] of Object.entries(preset.pairs)) { const input = fields.querySelector(`[name="corr:${pair}"]`); if (input) input.value = value }
    showToast(`${preset?.label || 'Conjunto'} aplicado. Calcule novamente para ver o efeito.`)
    return
  }

  const resetVolatility = event.target.closest('[data-reset-volatility]')
  if (resetVolatility) {
    const fields = resetVolatility.closest('[data-volatility-fields]')
    for (const [key, value] of Object.entries(classVolatility)) fields.querySelector(`[name="vol:${key}"]`).value = Math.round(value * 1000) / 10
    for (const [pair, value] of Object.entries(defaultClassCorrelations)) { const input = fields.querySelector(`[name="corr:${pair}"]`); if (input) input.value = value }
    return
  }

  const migrationToggle = event.target.closest('[data-resolve-migration], [data-reopen-migration]')
  if (migrationToggle) {
    const [table, id] = (migrationToggle.dataset.resolveMigration || migrationToggle.dataset.reopenMigration).split(':')
    try {
      setMigrationResolved(table, Number(id), Boolean(migrationToggle.dataset.resolveMigration))
      render()
      showToast(migrationToggle.dataset.resolveMigration ? 'Pendência marcada como resolvida. O alerta sai da avaliação.' : 'Pendência reaberta.')
    } catch (error) { showToast(error.message) }
    return
  }

  const allocationDimension = event.target.closest('[data-allocation-dimension]')
  if (allocationDimension) {
    allocationView.dimension = allocationDimension.dataset.allocationDimension
    render()
    return
  }

  if (event.target.closest('[data-clear-target-allocation]')) {
    setTargetAllocation(null)
    render()
    showToast('Alocação-alvo removida.')
    return
  }

  const removeInvestmentButton = event.target.closest('[data-remove-investment]')
  if (removeInvestmentButton) {
    if (!window.confirm('Excluir este investimento da carteira e recalcular o plano?')) return
    try {
      removeInvestment(removeInvestmentButton.dataset.removeInvestment)
      render()
      showToast('Investimento excluído e plano recalculado.')
    } catch (error) {
      showToast(error.message)
    }
    return
  }

  const openAnalysis = event.target.closest('[data-open-analysis]')
  const deleteAnalysis = event.target.closest('[data-delete-analysis]')
  if (openAnalysis || deleteAnalysis) {
    try {
      if (openAnalysis) statementHistoryView.activeId = openAnalysis.dataset.openAnalysis
      else {
        if (!window.confirm('Excluir este resumo do histórico? Os lançamentos já aplicados ao orçamento serão mantidos.')) return
        deleteStatementAnalysis(deleteAnalysis.dataset.deleteAnalysis)
        if (statementHistoryView.activeId === deleteAnalysis.dataset.deleteAnalysis) statementHistoryView.activeId = null
        statementHistoryView.comparison = null
      }
      render()
    } catch (error) { showToast(error.message) }
    return
  }
  const editScenarioButton = event.target.closest('[data-edit-scenario]')
  if (editScenarioButton || event.target.closest('[data-cancel-scenario-edit]')) {
    try {
      if (editScenarioButton) editScenario(editScenarioButton.dataset.editScenario)
      else clearScenarioEditor()
      render({ resetSimulation: true })
      document.querySelector('[name="scenarioName"]')?.focus()
    } catch (error) { showToast(error.message) }
    return
  }
  if (event.target.closest('[data-apply-simulation]')) {
    const form = document.querySelector('[data-simulation-form]')
    if (!form.reportValidity()) return
    try {
      const plan = simulationInputFromForm(form)
      projectRetirementWithSchedules(plan, simulationSchedules(plan))
      if (scenarioEditor.scenario) replaceFinancialData({ ...state, currency: simulationContext().currency, cashFlow: simulationCashFlow(plan), plan })
      else updatePlan(plan)
      navigate('/')
      showToast('Simulação aplicada ao plano principal.')
    } catch (error) {
      showToast(error.message)
    }
    return
  }

  if (event.target.closest('[data-save-scenario]')) {
    const form = document.querySelector('[data-simulation-form]')
    const name = new FormData(form).get('scenarioName')?.trim()
    if (!form.reportValidity()) return
    try {
      const plan = simulationInputFromForm(form)
      projectRetirementWithSchedules(plan, simulationSchedules(plan))
      const context = { ...simulationContext(), cashFlow: simulationCashFlow(plan) }
      if (scenarioEditor.scenario) updateScenario(scenarioEditor.scenario.id, name || scenarioEditor.scenario.name, plan, context)
      else addScenario(name || `Cenário ${state.scenarios.length + 1}`, plan, context)
      clearScenarioEditor()
      render({ resetSimulation: true })
      showToast('Cenário salvo para comparação.')
    } catch (error) {
      showToast(error.message)
    }
    return
  }

  const removeScenarioButton = event.target.closest('[data-remove-scenario]')
  if (removeScenarioButton) {
    removeScenario(removeScenarioButton.dataset.removeScenario)
    if (scenarioEditor.scenario?.id === removeScenarioButton.dataset.removeScenario) clearScenarioEditor()
    render({ resetSimulation: true })
    showToast('Cenário excluído.')
    return
  }

  const loadScenarioButton = event.target.closest('[data-load-scenario]')
  if (loadScenarioButton) {
    if (!window.confirm('Carregar este cenário como plano principal e substituir os dados atuais?')) return
    try {
      loadScenario(loadScenarioButton.dataset.loadScenario)
      navigate('/')
      showToast('Cenário carregado como plano principal.')
    } catch (error) {
      showToast(error.message)
    }
    return
  }

  const editCashItemButton = event.target.closest('[data-edit-cash-item]')
  if (editCashItemButton) {
    try {
      openCashItemDialog(editCashItemButton.dataset.editCashItem)
    } catch (error) {
      showToast(error.message)
    }
    return
  }

  if (event.target.closest('[data-close-cash-item-dialog]')) {
    closeCashItemDialog()
    return
  }

  const editAnnualGoalButton = event.target.closest('[data-edit-annual-goal]')
  if (editAnnualGoalButton) {
    try {
      openAnnualGoalDialog(editAnnualGoalButton.dataset.editAnnualGoal)
    } catch (error) {
      showToast(error.message)
    }
    return
  }

  if (event.target.closest('[data-close-annual-goal-dialog]')) {
    closeAnnualGoalDialog()
    return
  }

  if (event.target.closest('[data-close-statement-review]')) {
    closeStatementReview()
    showToast('Importação cancelada. Nenhum lançamento foi adicionado.')
    return
  }

  const removeCashItemButton = event.target.closest('[data-remove-cash-item]')
  if (removeCashItemButton) {
    const item = state.cashFlow.items.find(item => item.id === removeCashItemButton.dataset.removeCashItem)
    if (!item || !window.confirm(`Excluir ${item.description || 'este lançamento'}? O registro e suas repetições serão removidos do orçamento.`)) return
    try { removeCashFlowItem(removeCashItemButton.dataset.removeCashItem) } catch (error) { showToast(error.message); return }
    render()
    app.querySelector('[data-new-cash-item]')?.focus({ preventScroll: true })
    showToast('Lançamento excluído.')
    return
  }

  if (event.target.closest('[data-export-data]')) {
    exportData()
    return
  }

  if (event.target.closest('[data-reset-data]')) {
    if (!window.confirm('Restaurar os dados de demonstração? Seu plano, lançamentos, categorias e cenários salvos serão removidos.')) return
    try { dataHistory.clear() } catch { showToast('Não foi possível apagar as versões anteriores.'); return }
    const result = resetState()
    if (!result.success) {
      showToast('A demonstração foi aberta, mas dados anteriores podem não ter sido removidos. Tente apagar os dados novamente.')
      render()
      return
    }
    render()
    showToast('Dados de exemplo restaurados.')
    return
  }

  if (event.target.closest('[data-delete-data]')) {
    const confirmed = window.confirm('Apagar de forma irreversível o plano, os lançamentos, as categorias, os cenários, as moedas e as preferências deste navegador?')
    if (!confirmed) return

    const result = deleteLocalData()
    render()
    showToast(result.success
      ? 'Os dados deste navegador foram apagados.'
      : 'Não foi possível apagar todos os dados. Verifique o navegador e tente novamente.')
  }
})

let contributionImpactTimer = null

document.addEventListener('reset', event => {
  const form = event.target
  if (form.matches?.('[data-annual-planning="nonFinancialAssets"]')) form.querySelector('[data-property-setting]').hidden = false
})

// Reads the pre-drag value from the slider's defaultValue (set by the last
// full render) rather than state.plan.monthlyContribution, which this same
// handler already mutates on every tick — so it can't serve as the baseline.
function scheduleContributionImpact(input) {
  clearTimeout(contributionImpactTimer)
  contributionImpactTimer = setTimeout(() => {
    const impact = document.querySelector('[data-contribution-impact]')
    if (!impact) return
    const baseline = parseNumber(input.defaultValue)
    const value = parseNumber(input.value)
    if (baseline === value) { impact.textContent = 'Arraste o controle para ver o efeito na sua renda projetada.'; return }
    try {
      const schedules = currentRetirementSchedules()
      const before = projectRetirementWithSchedules({ ...state.plan, monthlyContribution: baseline }, schedules)
      const after = projectRetirementWithSchedules({ ...state.plan, monthlyContribution: value }, schedules)
      const delta = after.projectedMonthlyIncome - before.projectedMonthlyIncome
      const formatted = privateCurrency(Math.abs(delta), state.valuesHidden, false, state.currency)
      impact.textContent = Math.abs(delta) < 0.5
        ? 'Sem mudança relevante na renda projetada.'
        : `Isso ${delta > 0 ? 'aumenta' : 'reduz'} sua renda projetada em ${formatted}/mês aos ${state.plan.retirementAge} anos.`
    } catch {
      impact.textContent = 'Arraste o controle para ver o efeito na sua renda projetada.'
    }
  }, 150)
}

document.addEventListener('input', (event) => {
  const impactForm = event.target.closest('[data-expense-impact-form]')
  if (impactForm) {
    expenseImpactView.result = null
    impactForm.querySelector('[data-expense-impact-output]').innerHTML = '<p role="status">Parâmetros alterados. Compare novamente para atualizar o resultado.</p>'
    return
  }
  if (event.target.matches('[data-budget-filters] [name="search"]')) {
    readBudgetFilters(event.target.closest('form'))
    refreshBudgetResults()
    return
  }
  if (!event.target.matches('[data-plan-contribution]')) return

  const value = parseNumber(event.target.value)
  updatePlan({ monthlyContribution: value })
  event.target.style.setProperty('--range-progress', `${((value - 500) / 3500) * 100}%`)

  const output = document.querySelector('.contribution-output')
  if (output) output.textContent = privateCurrency(value, state.valuesHidden, false, state.currency)

  scheduleContributionImpact(event.target)
})

document.addEventListener('change', async (event) => {
  if (event.target.matches('[data-payment-filter]')) {
    paymentView.filter = event.target.value
    render()
    app.querySelector('[data-payment-filter]')?.focus({ preventScroll: true })
    return
  }
  const budgetFilters = event.target.closest('[data-budget-filters]')
  if (budgetFilters && !event.target.matches('[data-cash-flow-month]')) {
    readBudgetFilters(budgetFilters)
    refreshBudgetResults()
    return
  }
  if (event.target.matches('[data-recurring-choice]')) { const fields = event.target.closest('section').querySelector('[data-recurring-fields]'); fields.disabled = !event.target.checked; return }
  if (event.target.matches('[data-budget-owner]')) { budgetOwnerView.selected = event.target.value; render(); return }
  if (event.target.matches('[name="householdOwner"]')) { guideBudgetForm(event.target.closest('form'), state.customCategories); return }
  if (event.target.matches('[data-login-provider]')) { authState.loginProvider = event.target.value; return }

  if (event.target.matches('[data-property-solvency], [data-cash-flow-price-basis], [data-annual-chart-mode]')) {
    const yearControl = event.target.closest('[data-cash-flow-line-view]')?.querySelector('[data-cash-flow-year], [data-chart-year]')
    const selectedYear = yearControl?.selectedOptions[0]?.textContent.match(/^\d{4}/)?.[0]
    if (selectedYear) { timelineView.selectedYear = selectedYear; cashFlowChartView.selectedYear = selectedYear }
    const propertyControl = event.target.matches('[data-property-solvency]')
    if (propertyControl) {
      try { savePropertySolvencyPreference(event.target.checked) }
      catch { event.target.checked = state.cashFlow.includeRealEstateInSolvency !== false; showToast('Não foi possível salvar a opção de imóveis. Tente novamente.'); return }
    } else if (event.target.matches('[data-annual-chart-mode]')) {
      const mode = event.target.dataset.annualChartMode
      if (mode === 'wealth') cashFlowChartView.wealth = event.target.value === 'comparison' ? 'comparison' : 'essential'
      if (mode === 'flow') cashFlowChartView.flow = event.target.value === 'financial' ? 'financial' : 'budget'
    } else cashFlowChartView.basis = event.target.value === 'nominal' ? 'nominal' : 'real'
    const focusSelector = propertyControl ? '[data-property-solvency]' : event.target.matches('[data-annual-chart-mode]') ? `[data-annual-chart-mode="${event.target.dataset.annualChartMode}"]` : '[data-cash-flow-price-basis]'
    render()
    const control = app.querySelector(focusSelector)
    control?.focus({ preventScroll: true })
    if (propertyControl) showToast('Opção de imóveis salva. Solvência atualizada, caixa disponível preservado.')
    return
  }
  if (event.target.matches('[data-chart-year], [data-cash-flow-year]')) {
    const year = event.target.selectedOptions[0]?.textContent.match(/^\d{4}/)?.[0]
    if (year) { cashFlowChartView.selectedYear = year; timelineView.selectedYear = year }
  }
  if (event.target.matches('[data-annual-planning="nonFinancialAssets"] [name="category"]')) {
    event.target.form.querySelector('[data-property-setting]').hidden = event.target.value !== 'real-estate'
  }
  const importForm = event.target.closest('[data-finapp-import]')
  if (importForm) {
    finappPreviews.delete(importForm)
    importForm.querySelector('[data-finapp-review]').replaceChildren()
    importForm.querySelector('button[type="submit"]').textContent = 'Conferir arquivo e importar'
    importForm.querySelector('[data-finapp-status]').textContent = 'Arquivo ou modo alterado. Confira a nova prévia antes de aplicar.'
    return
  }
  if (event.target.matches('[data-withdraw-deficits]')) { variableView.withdrawDeficits = event.target.checked; render(); return }
  const budgetForm = event.target.closest('[data-guided-budget], [data-cash-item-form], [data-cash-item-edit-form]')
  if (budgetForm) guideBudgetForm(budgetForm, state.customCategories)
  if (event.target.matches('[data-timeline-period]')) {
    const yearControl = event.target.closest('section')?.querySelector('[data-cash-flow-year], [data-chart-year]')
    timelineView.selectedYear = yearControl?.selectedOptions[0]?.textContent.match(/^\d{4}/)?.[0] || null
    timelineView.period = ['target', '100', '12', '60', 'retirement'].includes(event.target.value) ? event.target.value : 'target'
    render()
    return
  }
  if (event.target.matches('[data-statement-mapping]')) {
    if (!statementReviewState) return
    statementReviewState.mapping[event.target.dataset.statementMapping] = Number(event.target.value)
    render()
    openStatementReviewDialog()
    return
  }

  if (event.target.matches('[data-statement-row]')) {
    if (!statementReviewState) return
    const rowNumber = Number(event.target.dataset.statementRow)
    if (event.target.checked) statementReviewState.excludedRows.delete(rowNumber)
    else statementReviewState.excludedRows.add(rowNumber)
    const review = statementReviewView()
    const count = document.querySelector('[data-statement-selected-count]')
    const confirm = document.querySelector('[data-statement-confirm]')
    const limitError = document.querySelector('[data-statement-limit-error]')
    if (count) count.textContent = String(review.selectedCount)
    if (confirm) {
      confirm.textContent = `Importar ${review.selectedCount} ${review.selectedCount === 1 ? 'lançamento' : 'lançamentos'}`
      confirm.disabled = review.selectedCount === 0 || review.overLimit
    }
    if (limitError) limitError.hidden = !review.overLimit
    return
  }

  if (event.target.matches('[data-volatility-model]')) {
    const group = event.target.closest('[data-volatility-fields]')?.querySelector('[data-class-volatility]')
    if (group) group.hidden = event.target.value !== 'class'
    return
  }

  if (event.target.matches('[data-spouse-plan] input[name="spouseEnabled"]')) {
    const form = event.target.closest('[data-spouse-plan]')
    const fields = form.querySelector('[data-spouse-fields]')
    if (fields) fields.hidden = !event.target.checked
    for (const name of ['spouseCurrentAge', 'spouseRetirementAge']) form.elements.namedItem(name).required = event.target.checked
    return
  }

  if (event.target.matches('[data-investment-form] select[name="liquidity"], [data-investment-form] select[name="assetClass"]')) {
    setInvestmentConditionalFields(event.target.closest('[data-investment-form]'))
    return
  }

  if (event.target.matches('[data-investment-form] select[name="returnType"]')) {
    setInvestmentReturnFields(event.target.closest('[data-investment-form]'))
    return
  }

  if (event.target.matches('select[name="recordKind"]')) {
    syncCashItemRecordFields(event.target.closest('form'))
    return
  }

  if (event.target.matches('[data-cash-flow-month]')) {
    try {
      setCashFlowReferenceMonth(event.target.value)
      render()
      app.querySelector('[data-cash-flow-month]')?.focus({ preventScroll: true })
      showToast('Mês de comparação atualizado.')
    } catch (error) {
      showToast(error.message)
    }
    return
  }

  if (event.target.matches('[data-statement-file]')) {
    const file = event.target.files?.[0]
    if (!file) return
    if (file.size > 1024 * 1024) {
      showToast('O arquivo deve ter no máximo 1 MB.')
      event.target.value = ''
      return
    }
    try {
      const generation = ownedStorage.generation
      const text = await file.text()
      if (generation !== ownedStorage.generation) return
      const inspection = inspectStatementText(text, { maximumRows: 100 })
      statementReviewState = {
        fileName: file.name,
        inspection,
        mapping: { ...inspection.suggestedMapping },
        excludedRows: new Set()
      }
      render()
      openStatementReviewDialog()
    } catch (error) {
      showToast(error.message)
      event.target.value = ''
    }
    return
  }

  if (event.target.matches('[data-currency]')) {
    const previousCurrency = state.currency
    setCurrency(event.target.value)
    render()
    showToast(`Visão geral alterada de ${previousCurrency} para ${state.currency}. Valores do plano foram convertidos pela cotação exibida.`)
    return
  }

  if (event.target.matches('[data-plan-contribution]')) {
    render()
    showToast('Aporte atualizado no seu plano.')
  }
})

document.addEventListener('submit', async (event) => {
  if (event.target.matches('[data-expense-impact-form]')) {
    event.preventDefault()
    try {
      if (state.valuesHidden) throw new Error('Mostre os valores antes de comparar.')
      calculateExpenseImpact(new FormData(event.target))
      event.target.querySelector('[data-form-error]')?.remove()
      event.target.querySelector('[data-expense-impact-output]').innerHTML = renderExpenseImpactResult()
    } catch (error) {
      expenseImpactView.result = null
      event.target.querySelector('[data-expense-impact-output]').replaceChildren()
      showFormError(event.target, error.message)
    }
    return
  }
  if (event.target.matches('[data-payment-form]')) {
    event.preventDefault()
    try {
      if (state.valuesHidden) throw new Error('Mostre os valores antes de confirmar.')
      const data = readMoneyFormData(event.target)
      if (data.get('confirmed') !== 'on') throw new Error('Confirme a conferência do movimento.')
      const paymentMatches = linkCalendarPayment(state.cashFlow, Object.fromEntries(data))
      updateCashFlow({ paymentMatches })
      paymentView.selectedKey = null
      paymentView.filter = 'all'
      render()
      const nextPayment = [...app.querySelectorAll('[data-payment-open]')].find(button => button.dataset.paymentOpen === data.get('eventKey'))
      ;(nextPayment || app.querySelector('[data-payment-filter]'))?.focus({ preventScroll: true })
      showToast('Movimento associado. Nenhum valor foi lançado novamente.')
    } catch (error) { showFormError(event.target, error.message) }
    return
  }
  if (event.target.matches('[data-budget-filters]')) {
    event.preventDefault()
    readBudgetFilters(event.target)
    refreshBudgetResults()
    return
  }
  const recurrenceForm = event.target.closest('[data-apply-recurrences]')
  if (recurrenceForm) {
    event.preventDefault()
    try {
      if (state.valuesHidden) throw new Error('Mostre os valores antes de aplicar as sugestões.')
      const data = readMoneyFormData(recurrenceForm)
      if (data.get('confirmed') !== 'on') throw new Error('Confirme a revisão dos itens selecionados.')
      const candidates = [...recurrenceForm.querySelectorAll('[data-recurring-choice]:checked')].map(input => {
        const index = Number(input.dataset.recurringChoice)
        return { index, ...Object.fromEntries(['description', 'categoryId', 'householdOwner', 'startDate', 'endDate'].map(key => [key, data.get(`${index}.${key}`)])), amount: Number(data.get(`${index}.amount`)) }
      })
      const count = applyStatementRecurrences(data.get('analysisId'), candidates)
      render()
      showToast(`${count} lançamento(s) planejado(s) adicionado(s). Confira o orçamento.`)
    } catch (error) { showFormError(recurrenceForm, error.message) }
    return
  }
  const comparisonForm = event.target.closest('[data-compare-analyses]')
  if (comparisonForm) {
    event.preventDefault()
    try {
      const data = new FormData(comparisonForm)
      const ids = [data.get('first'), data.get('second')]
      compareStatementPeriods(...ids.map(id => (state.cashFlow.statementAnalyses || []).find(row => row.id === id)))
      statementHistoryView.comparison = ids
      render()
    } catch (error) { showFormError(comparisonForm, error.message) }
    return
  }

  const confirmationForm = event.target.closest('[data-confirm-projection]')
  if (confirmationForm) {
    event.preventDefault()
    try {
      const data = new FormData(confirmationForm)
      confirmProjectionAssumption(data.get('field'), data.get('confirmed') === 'on')
      render()
      showToast('Premissa confirmada. Avaliação recalculada.')
    } catch (error) { showFormError(confirmationForm, error.message) }
    return
  }

  const settingsForm = event.target.closest('[data-enable-local-form], [data-storage-provider-form]')
  if (settingsForm) {
    event.preventDefault()
    const generation = ownedStorage.generation, owner = ownedStorage.owner
    const values = new FormData(settingsForm)
    const button = settingsForm.querySelector('button[type="submit"]')
    const feedback = document.querySelector('[data-local-settings-feedback]')
    button.disabled = true
    try {
      let result
      if (settingsForm.matches('[data-enable-local-form]')) {
        if (values.get('password') !== values.get('passwordConfirmation')) throw new Error('As senhas locais não são iguais.')
        result = await configureLocalAccess({ password: values.get('password'), acceptedSyncConsent: values.get('consent') === 'on', consentVersion: syncConsentVersion, state }, owner)
      } else result = await selectStorageProvider(values.get('provider'), owner)
      if (ownedStorage.generation !== generation) return
      Object.assign(authState, result)
      clearSyncComparison()
      resetSyncState()
      await loadSyncState()
      if (ownedStorage.generation !== generation) return
      render()
      const output = document.querySelector('[data-local-settings-feedback]')
      if (output) output.textContent = result.message || 'Destino da sincronização atualizado. Nenhuma cópia existente foi substituída.'
    } catch (error) { if (ownedStorage.generation === generation && feedback?.isConnected) feedback.textContent = error.message }
    finally { button.disabled = false }
    return
  }

  const bankAnalysisForm = event.target.closest('[data-bank-analysis]')
  if (bankAnalysisForm) {
    event.preventDefault()
    const result = document.querySelector('[data-bank-analysis-result]')
    const generation = ownedStorage.generation
    const button = bankAnalysisForm.querySelector('button[type="submit"]')
    button.disabled = true
    result.textContent = 'Lendo extrato…'
    try {
      if (state.valuesHidden) throw new Error('Ative a exibição de valores para analisar o extrato.')
      const analysis = await readStatementAnalysis(new FormData(bankAnalysisForm))
      if (generation !== ownedStorage.generation || !result.isConnected || state.valuesHidden) return
      saveStatementAnalysis(analysis, generation)
      statementHistoryView.activeId = analysis.id
      render()
      showToast('Resumo salvo no histórico. O orçamento não foi alterado.')
    } catch (error) { if (generation === ownedStorage.generation && result.isConnected) result.textContent = error.message }
    finally { button.disabled = false }
    return
  }

  if (!sessionReady) { event.preventDefault(); return }
  const viabilityForm = event.target.closest('[data-viability]')
  if (viabilityForm) {
    event.preventDefault()
    try { saveViability(new FormData(viabilityForm)); render(); showToast('Avaliação anual atualizada.') } catch (error) { showFormError(viabilityForm, error.message) }
    return
  }
  const horizonForm = event.target.closest('[data-planning-horizon]')
  if (horizonForm) {
    event.preventDefault()
    try {
      const data = new FormData(horizonForm)
      const patch = { targetAge: Number(data.get('targetAge')), horizonReferenceMonth: data.get('reference') }
      planningHorizon({ ...state.plan, ...patch }, state.cashFlow.referenceMonth)
      updatePlan(patch); cancelRisk(true); render(); showToast('Horizonte salvo. A idade de aposentadoria não foi alterada.')
    } catch (error) { showFormError(horizonForm, error.message) }
    return
  }
  const spouseForm = event.target.closest('[data-spouse-plan]')
  if (spouseForm) {
    event.preventDefault()
    try {
      const data = readMoneyFormData(spouseForm)
      const spouseEnabled = data.get('spouseEnabled') === 'on'
      const spouseCurrentAge = Number(data.get('spouseCurrentAge'))
      const spouseRetirementAge = Number(data.get('spouseRetirementAge'))
      const spouseExpectedMonthlyBenefit = Number(data.get('spouseExpectedMonthlyBenefit'))
      const spouseMonth = data.get('spouseRetirementMonth') || null
      if (spouseMonth && !/^(20|21)\d{2}-(0[1-9]|1[0-2])$/.test(spouseMonth)) throw new RangeError('Informe um mês válido para a aposentadoria do cônjuge.')
      if (spouseEnabled) {
        if (!Number.isFinite(spouseCurrentAge) || spouseCurrentAge < 16 || spouseCurrentAge > 99) throw new RangeError('Informe a idade atual do cônjuge (16 a 99 anos).')
        if (!Number.isFinite(spouseRetirementAge) || spouseRetirementAge <= spouseCurrentAge || spouseRetirementAge > 100) throw new RangeError('A idade de aposentadoria do cônjuge deve ser maior que a idade atual dele(a).')
      }
      updatePlan({
        spouseEnabled,
        spouseCurrentAge: spouseEnabled ? spouseCurrentAge : null,
        spouseRetirementAge: spouseEnabled ? spouseRetirementAge : null,
        spouseRetirementMonth: spouseEnabled ? spouseMonth : null,
        spouseExpectedMonthlyBenefit: Number.isFinite(spouseExpectedMonthlyBenefit) ? spouseExpectedMonthlyBenefit : 0
      })
      render()
      showToast(spouseEnabled ? 'Dados do cônjuge salvos no plano.' : 'Cônjuge removido do plano.')
    } catch (error) { showFormError(spouseForm, error.message) }
    return
  }
  const annualForm = event.target.closest('[data-annual-planning]')
  if (annualForm) {
    event.preventDefault()
    try { saveAnnualPlanning(readMoneyFormData(annualForm)); render(); showToast('Planejamento anual salvo.') } catch (error) { showFormError(annualForm, error.message) }
    return
  }
  const finappForm = event.target.closest('[data-finapp-import]')
  if (finappForm) {
    event.preventDefault()
    const owner = ownedStorage.owner
    const generation = ownedStorage.generation
    const original = serializeExportableState(state)
    const sameContext = () => sessionReady && owner && ownedStorage.owner === owner && ownedStorage.generation === generation && serializeExportableState(state) === original
    const button = finappForm.querySelector('button[type="submit"]')
    button.disabled = true
    try {
      if (!authState.authenticated || authState.user?.id !== owner) throw new Error('Entre na conta de destino antes de importar.')
      const file = finappForm.elements.namedItem('file').files[0]
      if (!file || file.size > 2000000) throw new Error('Selecione o JSON de importação, até 2 MB.')
      const fileText = await file.text()
      const parsed = parseFinappImport(fileText)
      const response = await fetch('/api/auth/status', { credentials: 'same-origin', cache: 'no-store' })
      const session = await response.json()
      if (!response.ok || !session.authenticated || session.user?.id !== owner || !sameContext()) throw new Error('A sessão ou os dados mudaram. Reabra o Perfil e tente novamente.')
      const mode = finappForm.elements.namedItem('mode').value
      const result = mergeFinappImport(state, parsed, mode)
      const preview = mode === 'horizon' ? `Conta: ${session.user.email || owner}. Atualizar somente a idade-alvo para ${result.state.plan.targetAge} anos, referência ${result.state.plan.horizonReferenceMonth}. Preservar investimentos, orçamento, cenários e aposentadoria. Confirmar com versão de recuperação?` : `Conta: ${session.user.email || owner}. ${mode === 'replace' ? `SUBSTITUIR ${result.removed} registros anteriores, incluindo contas, movimentos e cenários. Aplicar idade, inflação e retorno da origem, zerar reservas, benefício e meta de renda anteriores. Revisar idade desejada de aposentadoria.` : 'Preservar registros e premissas existentes.'} Importar ${result.added} registros, manter ${result.skipped} existentes e sinalizar ${result.unresolved || 0} conflitos ou possíveis duplicidades e guardar ${result.pending} pendências para revisão. Investimentos em ${state.currency}. Revise o LEIA-ME. Confirmar importação local com versão de recuperação?`
      finappForm.querySelector('[data-finapp-status]').textContent = preview
      const previewKey = JSON.stringify([owner, generation, original, mode, fileText])
      if (finappPreviews.get(finappForm) !== previewKey) {
        finappPreviews.set(finappForm, previewKey)
        finappForm.querySelector('[data-finapp-review]').innerHTML = renderFinappReconciliation(result.reconciliation || [], state.valuesHidden)
        button.textContent = 'Confirmar aplicação da prévia'
        return
      }
      if (!window.confirm(preview)) return
      if (!sameContext()) throw new Error('O contexto mudou. Nenhum dado foi importado.')
      if (result.added === 0 && ['merge', 'complete'].includes(mode)) { showToast(result.unresolved ? 'Nenhum faltante incluído. Revise os conflitos e possíveis duplicidades na prévia.' : 'Todos os registros compatíveis já estão importados.'); return }
      dataHistory.checkpoint(state)
      const candidate = { ...result.state, isDemo: false, lastUpdatedAt: new Date().toISOString() }
      // Fail before mutating memory if storage cannot hold the complete import.
      ownedStorage.setItem(storageKeys.current, JSON.stringify({ ...candidate, valuesHidden: state.valuesHidden }))
      replaceFinancialData(candidate)
      cancelRisk(true)
      recordDataOperation('file_import')
      render()
      showToast(mode === 'horizon' ? 'Idade-alvo atualizada sem alterar os registros importados.' : `${result.added} registros importados localmente. ${result.pending} pendências estão no relatório. Nenhum envio remoto.`)
    } catch (error) { showFormError(finappForm, error.message) }
    finally { button.disabled = false }
    return
  }
  const consortiumForm = event.target.closest('[data-consortium-form]')
  if (consortiumForm) {
    event.preventDefault()
    if (!consortiumForm.reportValidity()) return
    try { saveConsortium(readMoneyFormData(consortiumForm)); render(); showToast('Consórcio salvo. Parcelas e posição patrimonial atualizadas.') } catch (error) { showFormError(consortiumForm, error.message) }
    return
  }
  const riskForm = event.target.closest('[data-risk-form]')
  if (riskForm) {
    event.preventDefault()
    if (!riskForm.reportValidity()) return
    try { startRisk(riskSettingsFromForm(readMoneyFormData(riskForm)), () => { if (['/riscos', '/riscos-mensais'].includes(currentPath())) render() }); render() } catch (error) { showFormError(riskForm, error.message) }
    return
  }
  const ledgerStatementForm = event.target.closest('[data-ledger-statement]')
  if (ledgerStatementForm) {
    event.preventDefault()
    if (!ledgerStatementForm.reportValidity()) return
    const data = new FormData(ledgerStatementForm)
    const button = ledgerStatementForm.querySelector('[type="submit"], button')
    button.disabled = true
    try { await prepareLedgerStatement(data.get('file'), data.get('accountId')); render() }
    catch (error) { if (ledgerStatementForm.isConnected) showFormError(ledgerStatementForm, error.message) }
    finally { button.disabled = false }
    return
  }
  const linkForm = event.target.closest('[data-movement-reconciliation], [data-budget-link], [data-portfolio-link]')
  if (linkForm) {
    event.preventDefault()
    if (!linkForm.reportValidity()) return
    try {
      const data = readMoneyFormData(linkForm)
      if (linkForm.matches('[data-movement-reconciliation]')) reconcileLedgerMovement(data)
      else if (linkForm.matches('[data-budget-link]')) {
        if (!window.confirm('Aplicar o vínculo? Se você selecionou um realizado existente, ele será substituído pelo movimento, sem somar novamente.')) return
        linkMovementBudget(data)
      } else {
        if (data.get('confirm') !== 'on') throw new Error('Confirme a substituição do saldo.')
        if (!updatePortfolioFromAccount(data)) throw new Error('Atualizado somente nesta sessão. Não foi possível gravar no navegador. Exporte seus dados antes de sair.')
      }
      render(); showToast('Atualização concluída.')
    } catch (error) { showFormError(linkForm, error.message) }
    return
  }
  const planningForm = event.target.closest('[data-decumulation-form], [data-calendar-month], [data-commitment-form]')
  if (planningForm) {
    event.preventDefault()
    if (!planningForm.reportValidity()) return
    // Money fields use the Brazilian mask (20.000,00). Read them as numbers.
    const data = readMoneyFormData(planningForm)
    try {
      if (planningForm.matches('[data-decumulation-form]')) {
        const settings = { years: Number(data.get('years')), expenseMode: data.get('expenseMode'), annualFee: Number(data.get('annualFee')) / 100, withdrawalTax: Number(data.get('withdrawalTax')) / 100, benefitIncluded: data.get('benefitIncluded') === 'on' }
        validateDecumulation(settings)
        updatePlan({ decumulation: settings })
      } else if (planningForm.matches('[data-calendar-month]')) {
        if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(data.get('month'))) throw new Error('Mês inválido.')
        calendarView.month = data.get('month')
      } else saveCommitment(data)
      render()
    } catch (error) { showFormError(planningForm, error.message) }
    return
  }
  const reconciliationForm = event.target.closest('[data-reconciliation-form]')
  if (reconciliationForm) {
    event.preventDefault()
    if (!reconciliationForm.reportValidity()) return
    try { previewReconciliation(readMoneyFormData(reconciliationForm)); render() } catch (error) { showFormError(reconciliationForm, error.message) }
    return
  }
  const accountForm = event.target.closest('[data-account-form], [data-movement-form]')
  if (accountForm) {
    event.preventDefault()
    if (!accountForm.reportValidity()) return
    try { changeAccounts(accountForm.matches('[data-account-form]') ? 'account' : 'movement', readMoneyFormData(accountForm)); render() } catch (error) { showFormError(accountForm, error.message) }
    return
  }
  const guidedForm = event.target.closest('[data-guided-goal], [data-guided-assets], [data-guided-budget]')
  if (guidedForm) {
    event.preventDefault()
    if (!guidedForm.reportValidity()) return
    const data = readMoneyFormData(guidedForm)
    try {
      if (guidedForm.matches('[data-guided-goal]')) { saveGuidedGoal(data); navigate('/construir/orcamento') }
      else if (guidedForm.matches('[data-guided-assets]')) { saveGuidedAssets(data); navigate('/construir/revisao') }
      else {
        saveGuidedBudget(data)
        render()
        showToast('Lançamento adicionado. Você pode adicionar outro ou continuar.')
      }
    } catch (error) { showFormError(guidedForm, error.message) }
    return
  }
  const retirementMonthForm = event.target.closest('[data-budget-retirement-form]')
  if (retirementMonthForm) {
    event.preventDefault()
    if (!retirementMonthForm.reportValidity()) return
    try {
      setBudgetRetirementMonth(new FormData(retirementMonthForm).get('retirementMonth'))
      render()
      showToast('Mês confirmado. Receitas vinculadas foram recalculadas.')
    } catch (error) { showToast(error.message) }
    return
  }
  const portfolioCurrencyForm = event.target.closest('[data-portfolio-currency-form]')
  if (portfolioCurrencyForm) {
    event.preventDefault()
    if (!portfolioCurrencyForm.reportValidity()) return
    try {
      submitPortfolioCurrencyScenario(new FormData(portfolioCurrencyForm))
      render()
    } catch (error) { showToast(error.message) }
    return
  }
  const currencyForm = event.target.closest('[data-currency-scenario-form]')
  if (currencyForm) {
    event.preventDefault()
    const data = new FormData(currencyForm)
    const change = Number(data.get('shockPercent')) / 100
    if (!currencyForm.reportValidity() || !Number.isFinite(change) || change < -0.5 || change > 0.5) return
    currencyExplorer.currency = data.get('shockCurrency')
    currencyExplorer.change = change
    render()
    return
  }
  const currencyTrendsForm = event.target.closest('[data-currency-trends-form]')
  if (currencyTrendsForm) {
    event.preventDefault()
    const rates = {}
    for (const [name, value] of new FormData(currencyTrendsForm).entries()) if (name.startsWith('trend:') && value !== '') rates[name.slice(6)] = parseNumber(value) / 100
    if (Object.values(rates).some(value => !Number.isFinite(value) || value < -0.2 || value > 0.2)) { showToast('Informe tendências entre −20% e 20% ao ano.'); return }
    setCurrencyTrends(rates)
    render()
    showToast(state.plan.currencyTrends ? 'Tendência cambial aplicada à projeção.' : 'Projeção sem tendência cambial.')
    return
  }

  const investmentAssumptionsForm = event.target.closest('[data-investment-assumptions-form]')
  if (investmentAssumptionsForm) {
    event.preventDefault()
    const data = new FormData(investmentAssumptionsForm)
    const patch = {
      annualRealReturn: parseNumber(data.get('defaultRealReturn')) / 100,
      annualInflation: parseNumber(data.get('annualInflation')) / 100
    }
    try {
      projectRetirementWithSchedules({ ...state.plan, ...patch }, currentRetirementSchedules())
      updatePlan(patch)
      render()
      showToast('Premissas da carteira atualizadas.')
    } catch (error) {
      showToast(error.message)
    }
    return
  }

  const statementReviewForm = event.target.closest('[data-statement-review-form]')
  if (statementReviewForm) {
    event.preventDefault()
    const review = statementReviewView()
    if (!review || review.mappingErrors.length > 0 || review.overLimit) return
    const items = review.rows.filter((row) => row.selected).map((row) => row.item)
    try {
      const importedCount = importCashFlowItems(items)
      const skippedCount = review.duplicateCount + review.invalidCount
      statementReviewState = null
      render()
      app.querySelector('[data-open-budget-import]')?.focus({ preventScroll: true })
      showToast(`${importedCount} lançamentos importados.${skippedCount ? ` ${skippedCount} linhas não foram adicionadas.` : ''} Para consultar registros de outros meses, limpe os filtros e selecione Todos os períodos.`)
    } catch (error) {
      showToast(error.message)
    }
    return
  }

  const targetAllocationForm = event.target.closest('[data-target-allocation-form]')
  if (targetAllocationForm) {
    event.preventDefault()
    const data = new FormData(targetAllocationForm)
    const groups = { class: {}, currency: {}, region: {} }
    for (const [name, value] of data.entries()) {
      const [prefix, dimension, key] = name.split(':')
      if (prefix === 'target' && groups[dimension] && value !== '') groups[dimension][key] = parseNumber(value) / 100
    }
    const filled = group => Object.values(group).some(value => value > 0) ? group : undefined
    try {
      setTargetAllocation({ shares: filled(groups.class), currencyShares: filled(groups.currency), regionShares: filled(groups.region), band: parseNumber(data.get('targetBand')) / 100 })
      render()
      showToast('Alocação-alvo salva.')
    } catch (error) {
      showToast(error.message)
    }
    return
  }

  const investmentForm = event.target.closest('[data-investment-form]')
  if (investmentForm) {
    event.preventDefault()
    const data = readMoneyFormData(investmentForm)
    const returnType = data.get('returnType')
    try {
      const saved = upsertInvestment({
        id: data.get('investmentId') || undefined,
        name: data.get('investmentName'),
        assetClass: data.get('assetClass'),
        liquidity: data.get('liquidity'),
        amount: parseNumber(data.get('investmentAmount')),
        monthlyContribution: parseNumber(data.get('investmentContribution')),
        returnType,
        returnValue: returnType === 'default' ? null : parseNumber(data.get('investmentReturn')) / 100,
        indexAnnualRate: returnType === 'cdi' ? parseNumber(data.get('investmentIndexRate')) / 100 : null,
        annualRealReturns: parseAnnualRealReturns(data.get('investmentAnnualReturns') || ''),
        annualFee: data.get('investmentAnnualFee') ? parseNumber(data.get('investmentAnnualFee')) / 100 : 0,
        exposureCurrency: data.get('exposureCurrency') || state.currency,
        exposureShare: data.get('exposureShare') === '' || data.get('exposureShare') === null ? 1 : parseNumber(data.get('exposureShare')) / 100,
        region: data.get('region') || 'domestic',
        acquiredAt: data.get('investmentAcquiredAt') || null,
        releaseYear: data.get('investmentReleaseYear') || null
      })
      render()
      if (data.get('investmentId')) recordDataOperation('correction')
      showToast(`${saved.name} foi ${data.get('investmentId') ? 'atualizado' : 'adicionado'} na carteira.`)
    } catch (error) {
      showToast(error.message)
    }
    return
  }

  const syncForm = event.target.closest('[data-sync-consent-form]')
  if (syncForm) {
    event.preventDefault()
    const accepted = new FormData(syncForm).get('acceptedSyncConsent') === 'on'
    if (!accepted) {
      showToast(`Confirme o consentimento antes de criar a ${storageCopyLabel()}.`)
      return
    }
    if (syncState.exists && !window.confirm(`Substituir a ${storageCopyLabel()} pelos dados atuais deste navegador?`)) return
    const submitButton = syncForm.querySelector('[type="submit"]')
    submitButton.disabled = true
    try {
      await saveRemoteState(state)
      clearSyncComparison()
      recordDataOperation('upload')
      render()
      showToast(`${storageCopyLabel()} atualizada com seu consentimento.`)
    } catch (error) {
      submitButton.disabled = false
      showToast(error.message)
    }
    return
  }

  const cashItemEditForm = event.target.closest('[data-cash-item-edit-form]')
  if (cashItemEditForm) {
    event.preventDefault()
    try {
      const id = cashItemEditForm.elements.namedItem('itemId').value
      updateCashFlowItem(id, cashItemInputFromForm(cashItemEditForm))
      recordDataOperation('correction')
      finishBudgetSave('Lançamento atualizado.', id)
    } catch (error) {
      showFormError(cashItemEditForm, error.message)
    }
    return
  }

  const cashItemForm = event.target.closest('[data-cash-item-form]')
  if (cashItemForm) {
    event.preventDefault()
    try {
      addCashFlowItem(cashItemInputFromForm(cashItemForm))
      finishBudgetSave('Lançamento adicionado.', state.cashFlow.items.at(-1)?.id)
    } catch (error) {
      showFormError(cashItemForm, error.message)
    }
    return
  }

  const categoryForm = event.target.closest('[data-category-form]')
  if (categoryForm) {
    event.preventDefault()
    const data = new FormData(categoryForm)
    try {
      addCustomCategory(data.get('categoryName'), data.get('categoryType'))
      render()
      showToast('Categoria criada.')
    } catch (error) {
      showToast(error.message)
    }
    return
  }

  const reserveForm = event.target.closest('[data-reserve-form]')
  if (reserveForm) {
    event.preventDefault()
    try {
      updateCashFlow({ ...state.cashFlow, ...reserveInputFromForm(reserveForm) })
      render()
      showToast('Reserva atualizada.')
    } catch (error) {
      showToast(error.message)
    }
    return
  }

  const authForm = event.target.closest('[data-auth-form]')
  if (authForm) {
    event.preventDefault()
    const submitButton = authForm.querySelector('[type="submit"]')
    const feedback = document.querySelector('[data-auth-feedback]')
    const data = new FormData(authForm)
    const action = authForm.dataset.authForm
    submitButton.disabled = true
    feedback.textContent = ''
    feedback.classList.remove('is-error')

    try {
      let result
      if (action === 'login') {
        await login({ email: data.get('email'), password: data.get('password'), provider: data.get('provider') || 'supabase' })
        switchSessionPlan()
        statementReviewState = null
        try { localStorage.setItem(localLockKey, String(Date.now())) } catch {}
        closeLocalPlan()
        await loadSyncState()
        navigate('/inicio')
        showToast('Login realizado.')
        return
      }
      if (action === 'register') {
        result = await registerAccount({
          email: data.get('email'),
          password: data.get('password'),
          acceptedTerms: data.get('acceptedTerms') === 'on'
        })
        trackProductEvent('register_success')
      }
      if (action === 'recover') {
        if ((authState.provider === 'local' || authState.loginProvider === 'local') && data.get('password') !== data.get('passwordConfirmation')) throw new Error('As senhas informadas não são iguais.')
        result = await recoverAccount({ email: data.get('email'), recoveryCode: data.get('recoveryCode'), password: data.get('password'), provider: authState.provider === 'local' || authState.loginProvider === 'local' ? 'local' : 'supabase' })
      }
      if (action === 'password') {
        if (data.get('password') !== data.get('passwordConfirmation')) {
          throw new Error('As senhas informadas não são iguais.')
        }
        result = await updatePassword({ password: data.get('password') })
        Object.assign(authState, { authenticated: false, user: null })
        switchSessionPlan()
        closeLocalPlan()
        navigate('/entrar')
        showToast(result.message)
        return
      }
      feedback.textContent = result?.message || 'Operação concluída.'
      authForm.reset()
    } catch (error) {
      feedback.textContent = error.message
      feedback.classList.add('is-error')
    } finally {
      submitButton.disabled = false
    }
    return
  }

  const form = event.target.closest('[data-simulation-form]')
  if (!form) return
  event.preventDefault()

  const resultContainer = document.querySelector('#simulation-result-content')

  try {
    const simulationPlan = simulationInputFromForm(form)
    const result = projectRetirementWithSchedules(simulationPlan, simulationSchedules(simulationPlan))
    resultContainer.innerHTML = renderSimulationResult(result, simulationPlan, simulationContext().currency)
    resultContainer.closest('.simulation-result')?.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    })
    showToast('Projeção atualizada.')
  } catch (error) {
    const errorBox = document.createElement('div')
    errorBox.className = 'form-error'
    errorBox.setAttribute('role', 'alert')
    errorBox.textContent = String(error.message)
    resultContainer.replaceChildren(errorBox)
  }
})

window.addEventListener('popstate', () => { resetExpenseImpact(); render({ focusMain: true, indicateRecalculation: false }) })
bindMonthlyHints(document)
bindPageTabs(app)
document.addEventListener('input', event => {
  const group = event.target.closest?.('[data-target-dimension]')
  if (!group) return
  const inputs = [...group.querySelectorAll('input[name^="target:"]')]
  const total = inputs.reduce((sum, input) => sum + (parseNumber(input.value || 0) || 0), 0)
  const output = group.querySelector('[data-target-allocation-total]')
  if (output) output.textContent = inputs.every(input => input.value === '' || parseNumber(input.value) === 0) ? 'Deixe em branco para não usar este alvo.' : `Soma atual: ${total.toLocaleString('pt-BR', { maximumFractionDigits: 1 })}%. ${Math.abs(total - 100) <= 0.5 ? 'Pronto para salvar.' : 'A soma precisa ser 100%.'}`
})
document.addEventListener('input', event => {
  const consortium = event.target.closest('[data-consortium-form]')
  if (consortium) guideConsortiumForm(consortium)
  const movement = event.target.closest('[data-movement-form]')
  if (movement) guideMovementForm(movement, state.cashFlow.ledger.accounts)
  const commitment = event.target.closest('[data-commitment-form]')
  if (commitment) guideCommitmentForm(commitment)
})
document.addEventListener('reset', event => {
  queueMicrotask(() => {
    if (event.target.matches('[data-consortium-form]')) { event.target.elements.namedItem('id').value = ''; guideConsortiumForm(event.target) }
    if (event.target.matches('[data-commitment-form]')) {
      event.target.elements.namedItem('id').value = ''
      event.target.querySelector('[data-form-error]')?.remove()
      guideCommitmentForm(event.target)
    }
    if (event.target.matches('[data-movement-form]')) guideMovementForm(event.target, state.cashFlow.ledger.accounts)
  })
})
window.addEventListener('storage', async event => {
  if (event.key === localLockKey) {
    cancelRisk(true)
    closeLocalPlan()
    sessionReady = false
    statementReviewState = null
    render()
    await loadAuthState()
    switchSessionPlan()
    sessionReady = true
    render()
  }
})

document.addEventListener('cancel', (event) => {
  if (!event.target.matches('[data-statement-review-dialog]')) return
  event.preventDefault()
  closeStatementReview()
  showToast('Importação cancelada. Nenhum lançamento foi adicionado.')
}, true)

let sessionReady = false
render({ indicateRecalculation: false })
loadAuthState().then(async () => {
  switchSessionPlan()
  sessionReady = true
  render({ indicateRecalculation: false })
  // Public quotes must not block opening the local plan when the network is slow.
  loadExchangeRates().then(() => { if (['/', '/inicio', '/cambio'].includes(currentPath())) render({ indicateRecalculation: false }) })
  if (authState.authenticated) {
    await loadSyncState()
    if (['/', '/inicio', '/perfil'].includes(currentPath())) render({ indicateRecalculation: false })
  }
})
