import test from 'node:test'
import assert from 'node:assert/strict'

import {
  createExportableState,
  loadStoredState,
  parseStoredState,
  removeStoredState,
  sanitizeCashFlow,
  sanitizePlan,
  sanitizeStoredState,
  serializeExportableState,
  stateVersion,
  storageKeys
} from '../src/app/state-storage.js'

function memoryStorage(entries = {}) {
  const memory = new Map(Object.entries(entries))
  return {
    memory,
    getItem: (key) => memory.get(key) ?? null,
    setItem: (key, value) => memory.set(key, value),
    removeItem: (key) => memory.delete(key)
  }
}

test('recupera estado padrão quando o armazenamento contém null ou JSON inválido', () => {
  assert.equal(parseStoredState('null').version, stateVersion)
  assert.equal(parseStoredState('{invalido').version, stateVersion)
})

test('ignora números inválidos e propriedades desconhecidas do plano', () => {
  const plan = sanitizePlan({ currentAge: '40', currentAssets: -1, unknown: 123 })
  assert.equal(plan.currentAge, 39)
  assert.equal(plan.currentAssets, 120000)
  assert.equal('unknown' in plan, false)
})

test('sanitiza investimentos e deriva patrimônio e aporte pelos itens', () => {
  const plan = sanitizePlan({
    currentAssets: 999999,
    monthlyContribution: 9999,
    investments: [
      { id: 'tesouro', name: 'Tesouro IPCA', assetClass: 'fixed-income', amount: 40000, monthlyContribution: 500, annualRealReturn: null },
      { id: 'acoes', name: 'Ações', assetClass: 'equity', amount: 10000, monthlyContribution: 200, annualRealReturn: 0.07 },
      { id: 'invalido', name: '', amount: -1 }
    ]
  })

  assert.equal(plan.investments.length, 2)
  assert.equal(plan.currentAssets, 50000)
  assert.equal(plan.monthlyContribution, 700)
  assert.equal(plan.investments[0].returnType, 'default')
  assert.equal(plan.investments[1].returnType, 'real')
  assert.equal(plan.investments[1].returnValue, 0.07)
})

test('cônjuge desabilitado zera os campos relacionados mesmo se enviados', () => {
  const plan = sanitizePlan({
    spouseEnabled: false,
    spouseCurrentAge: 40,
    spouseRetirementAge: 60,
    spouseRetirementMonth: '2045-01',
    spouseExpectedMonthlyBenefit: 2000
  })
  assert.equal(plan.spouseEnabled, false)
  assert.equal(plan.spouseCurrentAge, null)
  assert.equal(plan.spouseRetirementAge, null)
  assert.equal(plan.spouseRetirementMonth, null)
  assert.equal(plan.spouseExpectedMonthlyBenefit, 0)
})

test('cônjuge habilitado mantém idades válidas e corrige aposentadoria anterior à idade atual', () => {
  const plan = sanitizePlan({
    spouseEnabled: true,
    spouseCurrentAge: 45,
    spouseRetirementAge: 40,
    spouseExpectedMonthlyBenefit: 1800
  })
  assert.equal(plan.spouseEnabled, true)
  assert.equal(plan.spouseCurrentAge, 45)
  assert.equal(plan.spouseRetirementAge, 46)
  assert.equal(plan.spouseExpectedMonthlyBenefit, 1800)
})

test('sanitiza o fluxo de caixa e mantém apenas campos aprovados', () => {
  const cashFlow = sanitizeCashFlow({ recurringIncome: 15000, essentialExpenses: -1, secret: 123 })
  assert.equal(cashFlow.recurringIncome, 15000)
  assert.equal(cashFlow.essentialExpenses, 5500)
  assert.equal('secret' in cashFlow, false)
})

test('migra lançamentos antigos para planejados e extratos para realizados', () => {
  const cashFlow = sanitizeCashFlow({
    referenceMonth: '2026-09',
    items: [
      { id: 'old', type: 'income', categoryId: 'salary', amount: 1000, currency: 'BRL', frequency: 'monthly' },
      { id: 'txt', type: 'expense', categoryId: 'groceries', amount: 50, currency: 'BRL', frequency: 'occasional', source: 'txt', startDate: '2026-09-04' },
      { id: 'invalid-actual', type: 'expense', categoryId: 'groceries', amount: 20, currency: 'BRL', frequency: 'occasional', recordKind: 'actual' }
    ]
  })

  assert.equal(cashFlow.referenceMonth, '2026-09')
  assert.equal(cashFlow.items[0].recordKind, 'planned')
  assert.equal(cashFlow.items[1].recordKind, 'actual')
  assert.equal(cashFlow.items.length, 2)
})

test('migra estado antigo e limita cenários a três', () => {
  const scenarios = Array.from({ length: 5 }, (_, index) => ({
    id: `s-${index}`,
    name: `Cenário ${index}`,
    plan: {}
  }))
  const state = sanitizeStoredState({ activeChartRange: 'invalid', scenarios })

  assert.equal(state.version, stateVersion)
  assert.equal(state.activeChartRange, 'retirement')
  assert.equal(state.currency, 'BRL')
  assert.equal(state.scenarios.length, 3)
})

test('preserva apenas moedas base permitidas', () => {
  assert.equal(sanitizeStoredState({ currency: 'eur' }).currency, 'EUR')
  assert.equal(sanitizeStoredState({ currency: 'BTC' }).currency, 'BRL')
})

test('preserva um plano salvo na versão antiga como dado do usuário', () => {
  const state = sanitizeStoredState({ plan: { currentAge: 45 } })
  assert.equal(state.plan.currentAge, 45)
  assert.equal(state.isDemo, false)
})

test('migra o estado legado e só então remove sua chave', () => {
  const storage = memoryStorage({
    [storageKeys.legacy]: JSON.stringify({ plan: { currentAge: 46 } })
  })

  const state = loadStoredState(storage)

  assert.equal(state.plan.currentAge, 46)
  assert.ok(storage.memory.has(storageKeys.current))
  assert.equal(storage.memory.has(storageKeys.legacy), false)
})

test('mantém o legado quando não consegue concluir a migração', () => {
  const storage = memoryStorage({
    [storageKeys.legacy]: JSON.stringify({ plan: { currentAge: 46 } })
  })
  storage.setItem = () => { throw new Error('indisponível') }

  loadStoredState(storage)

  assert.equal(storage.memory.has(storageKeys.legacy), true)
})

test('apaga apenas as chaves do Aposenta+', () => {
  const storage = memoryStorage({
    [storageKeys.current]: '{}',
    [storageKeys.legacy]: '{}',
    [storageKeys.older]: '{}',
    [storageKeys.oldest]: '{}',
    [storageKeys.earlier]: '{}',
    [storageKeys.earliest]: '{}',
    [storageKeys.original]: '{}',
    [storageKeys.first]: '{}',
    [storageKeys.initial]: '{}',
    'outro-aplicativo': 'preservar'
  })

  const result = removeStoredState(storage)

  assert.equal(result.success, true)
  assert.equal(storage.memory.get('outro-aplicativo'), 'preservar')
  assert.equal(storage.memory.get(storageKeys.deletionMarker), '1')
  assert.equal(removeStoredState(storage).success, true)
})

test('tenta apagar todas as chaves mesmo quando uma remoção falha', () => {
  const attempted = []
  const storage = {
    setItem() {},
    removeItem(key) {
      attempted.push(key)
      if (key === storageKeys.current) throw new Error('bloqueado')
    }
  }

  const result = removeStoredState(storage)

  assert.deepEqual(attempted, ['aposenta-plus-data-history-v1', storageKeys.current, storageKeys.previous, storageKeys.legacy, storageKeys.older, storageKeys.oldest, storageKeys.earlier, storageKeys.earliest, storageKeys.original, storageKeys.first, storageKeys.initial])
  assert.equal(result.success, false)
  assert.deepEqual(result.failedKeys, [storageKeys.current])
})

test('mantém estado vazio após exclusão e nova carga', () => {
  const storage = memoryStorage({
    [storageKeys.current]: JSON.stringify({ plan: { currentAssets: 999999 } })
  })

  assert.equal(removeStoredState(storage).success, true)
  const reloaded = loadStoredState(storage)

  assert.equal(reloaded.dataDeleted, true)
  assert.equal(reloaded.plan.currentAssets, 120000)
  assert.equal(reloaded.scenarios.length, 0)
})

test('exporta somente campos aprovados e dados sanitizados', () => {
  const exported = createExportableState({
    plan: { currentAge: 47, segredo: 'não exportar' },
    token: 'não exportar'
  })
  const parsed = JSON.parse(serializeExportableState(exported))

  assert.deepEqual(Object.keys(parsed), [
    'version',
    'valuesHidden',
    'reminderEnabled',
    'isDemo',
    'lastUpdatedAt',
    'activeChartRange',
    'currency',
    'exchangeRates',
    'customCategories',
    'plan',
    'cashFlow',
    'scenarios'
  ])
  assert.equal(parsed.plan.currentAge, 47)
  assert.equal(parsed.currency, 'BRL')
  assert.equal('segredo' in parsed.plan, false)
  assert.equal('token' in parsed, false)
})
