import test from 'node:test'
import assert from 'node:assert/strict'

import {
  projectAssetSeriesDetailed,
  projectAssetSeries,
  projectAssetSeriesWithSchedules,
  projectRetirement,
  projectRetirementWithSchedules,
  validateProjectionInput,
  yearsUntilGoal
} from '../src/domain/retirement.js'

const baseInput = {
  currentAge: 35,
  retirementAge: 65,
  currentAssets: 50000,
  monthlyContribution: 1000,
  annualRealReturn: 0.05,
  targetMonthlyIncome: 8000,
  expectedMonthlyBenefit: 3500,
  annualWithdrawalRate: 0.04
}

function assertClose(actual, expected, tolerance = 0.02) {
  assert.ok(
    Math.abs(actual - expected) <= tolerance,
    `Esperava ${expected}, recebeu ${actual}`
  )
}

test('projeta patrimônio e renda para o cenário base', () => {
  const result = projectRetirement(baseInput)

  assert.equal(result.months, 360)
  assertClose(result.projectedAssets, 1031473.03)
  assertClose(result.targetAssets, 1350000)
  assertClose(result.projectedMonthlyIncome, 6938.24)
  assertClose(result.monthlyIncomeGap, 1061.76)
  assertClose(result.requiredMonthlyContribution, 1390.65)
  assert.equal(result.goalReached, false)
})

test('calcula aportes sem retorno real', () => {
  const result = projectRetirement({
    ...baseInput,
    currentAssets: 0,
    annualRealReturn: 0
  })

  assert.equal(result.projectedAssets, 360000)
  assert.equal(result.monthlyRate, 0)
  assert.equal(result.requiredMonthlyContribution, 3750)
})

test('identifica meta atingida', () => {
  const result = projectRetirement({
    ...baseInput,
    currentAssets: 500000,
    monthlyContribution: 4000
  })

  assert.equal(result.goalReached, true)
  assert.ok(result.monthlyIncomeGap < 0)
  assert.ok(result.progress > 1)
})

test('trata renda já coberta pelo benefício', () => {
  const result = projectRetirement({
    ...baseInput,
    targetMonthlyIncome: 3000,
    expectedMonthlyBenefit: 3500
  })

  assert.equal(result.targetAssets, 0)
  assert.equal(result.progress, 1)
  assert.equal(result.requiredMonthlyContribution, 0)
  assert.equal(result.goalReached, true)
})

test('rejeita idades e valores inválidos', () => {
  assert.throws(
    () => validateProjectionInput({ ...baseInput, retirementAge: 30 }),
    /maior que a idade atual/
  )
  assert.throws(
    () => validateProjectionInput({ ...baseInput, currentAssets: -1 }),
    /não pode ser negativo/
  )
  assert.throws(
    () => validateProjectionInput({ ...baseInput, annualWithdrawalRate: 0 }),
    /taxa de retirada/
  )
})

test('encontra o primeiro prazo anual que alcança a meta', () => {
  const years = yearsUntilGoal({
    ...baseInput,
    retirementAge: 65,
    monthlyContribution: 2000
  })

  assert.equal(years, 26)
})

test('gera série anual coerente com a projeção final', () => {
  const series = projectAssetSeries(baseInput, 30)
  const result = projectRetirement(baseInput)

  assert.equal(series.length, 31)
  assertClose(series.at(-1).assets, result.projectedAssets)
})

test('decompõe o saldo entre capital aportado e rendimento real composto', () => {
  const series = projectAssetSeriesDetailed(baseInput, 30)
  const last = series.at(-1)

  assert.equal(last.contributedCapital, baseInput.currentAssets + baseInput.monthlyContribution * 360)
  assertClose(last.contributedCapital + last.investmentGrowth, last.assets)
  assert.ok(last.investmentGrowth > 0)
})

test('mantém resultados finitos quando renda desejada e benefício são zero', () => {
  const result = projectRetirement({
    ...baseInput,
    targetMonthlyIncome: 0,
    expectedMonthlyBenefit: 0
  })

  for (const value of Object.values(result)) {
    if (typeof value === 'number') assert.equal(Number.isFinite(value), true)
  }
})

test('mais aporte não reduz o patrimônio projetado', () => {
  const base = projectRetirement(baseInput)
  const increased = projectRetirement({ ...baseInput, monthlyContribution: 1500 })
  assert.ok(increased.projectedAssets > base.projectedAssets)
})

test('contribuições previdenciárias programadas aumentam o patrimônio somente durante o prazo', () => {
  const input = {
    ...baseInput,
    currentAge: 40,
    retirementAge: 42,
    currentAssets: 0,
    monthlyContribution: 100,
    annualRealReturn: 0,
    targetMonthlyIncome: 0,
    expectedMonthlyBenefit: 0
  }
  const schedules = [{ amount: 50, startDate: '2026-09-01', endDate: '2027-08-31' }]
  const result = projectRetirementWithSchedules(input, schedules, new Date('2026-09-04T12:00:00Z'))
  const series = projectAssetSeriesWithSchedules(input, schedules, 2, new Date('2026-09-04T12:00:00Z'))

  assert.equal(result.scheduledContributionTotal, 600)
  assert.equal(result.currentScheduledMonthlyContribution, 50)
  assert.equal(result.projectedAssets, 3000)
  assert.equal(series.at(-1).assets, 3000)
  assert.equal(series.at(-1).scheduledContributionTotal, 600)
})

test('projeta cada investimento com seu próprio retorno real', () => {
  const result = projectRetirement({
    ...baseInput,
    currentAge: 40,
    retirementAge: 41,
    currentAssets: 999999,
    monthlyContribution: 0,
    investments: [
      { amount: 1000, monthlyContribution: 0, annualRealReturn: null },
      { amount: 1000, monthlyContribution: 0, annualRealReturn: 0.21 }
    ],
    annualRealReturn: 0
  })

  assertClose(result.currentAssets, 2000)
  assertClose(result.futureCurrentAssets, 2210)
  assertClose(result.projectedAssets, 2210)
})

test('retorno padrão muda somente investimentos sem taxa específica', () => {
  const input = {
    ...baseInput,
    currentAge: 40,
    retirementAge: 41,
    currentAssets: 2000,
    monthlyContribution: 0,
    investments: [
      { amount: 1000, monthlyContribution: 0, annualRealReturn: null },
      { amount: 1000, monthlyContribution: 0, annualRealReturn: 0.10 }
    ]
  }
  const fivePercent = projectRetirement({ ...input, annualRealReturn: 0.05 })
  const zeroPercent = projectRetirement({ ...input, annualRealReturn: 0 })

  assertClose(fivePercent.futureCurrentAssets, 2150)
  assertClose(zeroPercent.futureCurrentAssets, 2100)
})

test('aportes seguem a distribuição e o retorno de cada investimento', () => {
  const result = projectRetirement({
    ...baseInput,
    currentAge: 40,
    retirementAge: 41,
    currentAssets: 0,
    monthlyContribution: 200,
    annualRealReturn: 0,
    investments: [
      { amount: 0, monthlyContribution: 100, annualRealReturn: 0 },
      { amount: 0, monthlyContribution: 100, annualRealReturn: 0.12 }
    ]
  })

  assert.ok(result.futureContributions > 2400)
  assertClose(result.projectedAssets, result.futureContributions)
})

test('inflação altera somente a conversão de retorno nominal da carteira', () => {
  const input = {
    ...baseInput,
    currentAge: 40,
    retirementAge: 41,
    currentAssets: 1000,
    monthlyContribution: 0,
    annualInflation: 0.05,
    investments: [
      { amount: 1000, monthlyContribution: 0, returnType: 'nominal', returnValue: 0.10, indexAnnualRate: null }
    ]
  }

  const fivePercentInflation = projectRetirement(input)
  const tenPercentInflation = projectRetirement({ ...input, annualInflation: 0.10 })

  assertClose(fivePercentInflation.futureCurrentAssets, 1000 * 1.10 / 1.05)
  assertClose(tenPercentInflation.futureCurrentAssets, 1000)
})

test('inclui o benefício do cônjuge quando ele já se aposentou antes do titular', () => {
  const withoutSpouse = projectRetirement(baseInput)
  const withSpouse = projectRetirement({
    ...baseInput,
    spouseEnabled: true,
    spouseCurrentAge: 40,
    spouseRetirementAge: 60,
    spouseExpectedMonthlyBenefit: 2000
  })

  assert.equal(withSpouse.spouseMonths, 240)
  assertClose(withSpouse.spouseMonthlyBenefit, 2000)
  assertClose(withSpouse.householdExpectedMonthlyBenefit, baseInput.expectedMonthlyBenefit + 2000)
  assert.ok(withSpouse.projectedMonthlyIncome > withoutSpouse.projectedMonthlyIncome)
  assertClose(withSpouse.projectedAssets, withoutSpouse.projectedAssets)
})

test('não soma o benefício do cônjuge antes da aposentadoria dele', () => {
  const result = projectRetirement({
    ...baseInput,
    spouseEnabled: true,
    spouseCurrentAge: 35,
    spouseRetirementAge: 70,
    spouseExpectedMonthlyBenefit: 2000
  })

  assert.equal(result.spouseMonths, 420)
  assertClose(result.spouseMonthlyBenefit, 0)
  assertClose(result.householdExpectedMonthlyBenefit, baseInput.expectedMonthlyBenefit)
})

test('cônjuge habilitado sem idades nem mês de aposentadoria é rejeitado', () => {
  assert.throws(() => projectRetirement({
    ...baseInput,
    spouseEnabled: true,
    spouseExpectedMonthlyBenefit: 1000
  }), TypeError)
})

test('idade de aposentadoria do cônjuge deve ser maior que a idade atual dele', () => {
  assert.throws(() => projectRetirement({
    ...baseInput,
    spouseEnabled: true,
    spouseCurrentAge: 60,
    spouseRetirementAge: 55,
    spouseExpectedMonthlyBenefit: 1000
  }), RangeError)
})

test('projectRetirementWithSchedules usa a renda familiar com o benefício do cônjuge', () => {
  const result = projectRetirementWithSchedules({
    ...baseInput,
    spouseEnabled: true,
    spouseCurrentAge: 40,
    spouseRetirementAge: 60,
    spouseExpectedMonthlyBenefit: 1500
  }, [])

  assertClose(result.projectedMonthlyIncome - result.projectedInvestmentIncome, baseInput.expectedMonthlyBenefit + 1500)
})
